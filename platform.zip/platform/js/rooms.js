// FILE: js/rooms.js
/*
 * Room engine: registry, room entry, exits, [E] props, the kitchen trapdoor, steam hazards, the boss-trap
 * cutscene and all room drawing. Room data lives in rooms_data.js (its header documents the shape); this file
 * loads first so the data file can call registerRoom.
 * Extension points: registerRoom(id, data) adds a room; a new prop kind = one entry each in USE, PROMPT and DRAW.
 */
(function (Z) {
  'use strict';

  var Rd = Z.Render;
  var PAD = 30;                           // px around a prop within which [E] works
  var ROOMS = {};
  // DECISION: the tarantula's key is dropped, not placed, so leaving without it would lose it for good. Rooms listed
  // here re-drop the item on entry while the flag is set and the player does not own it (a room may add its own `rescue`).
  var RESCUE = { sklad_narzedzi: [{ flag: 'tarantulaDead', id: 'key_chute', x: 910, y: 650 }] };

  // Per-visit state; all of it resets in enter(), so none of it needs saving.
  var trap = { open: 0, cool: 0 };        // kitchen trapdoor: frames left open / lever cooldown frames left
  var valveT = 0;                         // frames [E] has been held on the bunker valve
  var msgCool = 0;                        // throttles repeated "locked" toasts at screen edges
  var roomT = 0;                          // frames since entering (drives the steam cycle)
  var flash = 0;                          // light surge when the fuse goes in
  var cut = null, cutPending = false;     // boss-trap cutscene
  var staticBoss = null;                  // the caged boss, for a save that loads after the trap
  var shadeGrad = null, lightCache = {};

  /* ------------------------------------------------------------ helpers */

  function ov(a, b) { return Rd.overlap(a, b); }
  function say(g, text) { Z.Items.say(g, text); }
  function click() { Z.Audio.play('click'); }

  function rect(ctx, x, y, w, h, fill, stroke) {
    ctx.fillStyle = fill;
    ctx.fillRect(x, y, w, h);
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); }
  }

  /** Lighter version of a #rrggbb colour (cached); gives platforms their 2 px lighter outline. */
  function lighten(hex, amt) {
    var key = hex + amt, n;
    if (lightCache[key]) return lightCache[key];
    if (typeof hex !== 'string' || hex.length !== 7) return hex;
    n = parseInt(hex.slice(1), 16);
    lightCache[key] = 'rgb(' + Math.min(255, (n >> 16) + amt) + ',' + Math.min(255, ((n >> 8) & 255) + amt) + ',' + Math.min(255, (n & 255) + amt) + ')';
    return lightCache[key];
  }

  function solidAt(room, box) {
    for (var i = 0; i < room.platforms.length; i++) if (ov(box, room.platforms[i])) return true;
    return false;
  }

  /** Non-consuming check: is this requirement already met? */
  function isOpen(g, need) {
    if (!need) return true;
    if (need.flag) return !!g.flags[need.flag];
    if (need.used) return Z.Inventory.wasUsed(g, need.used);
    if (need.item) return Z.Inventory.wasUsed(g, need.item);
    return true;
  }

  /** 0 = refused, 1 = already satisfied, 2 = satisfied just now by spending a key item. */
  function satisfy(g, need) {
    if (isOpen(g, need)) return 1;
    if (need.item && Z.Inventory.consume(g, need.item)) return 2;
    return 0;
  }

  /* ------------------------------------------------------------ registry + entering rooms */

  /**
   * Registers (or replaces) a room. Sequels call this from their own data file.
   * @param {string} id room id, e.g. 'salon'
   * @param {object} data room definition (shape documented at the top of rooms_data.js)
   * @returns {object} the registered definition
   */
  function registerRoom(id, data) {
    data.id = id;
    data.spawns = data.spawns || {};
    if (!data.spawns.default) data.spawns.default = { x: 60, y: 602 };
    ROOMS[id] = data;
    return data;
  }

  /** Per-visit copy of a definition: runtime changes (trapdoor plank, lights on in the cutscene) never touch the registry. */
  function buildRoom(def) {
    var r = {}, k, i;
    for (k in def) r[k] = def[k];
    r.platforms = (def.platforms || []).slice();
    r.exits = def.exits || [];
    r.props = def.props || [];
    r.deco = def.deco || [];
    r.hazards = def.hazards || [];
    r.trapProp = null; r.trapPlat = null;
    for (i = 0; i < r.props.length; i++) {
      if (r.props[i].kind === 'trapdoor') {
        r.trapProp = r.props[i];
        r.trapPlat = { x: r.trapProp.x, y: r.trapProp.y, w: r.trapProp.w, h: r.trapProp.h };
      }
    }
    return r;
  }

  /** Places the player standing at (x, y), crouched instead if a ceiling is in the way (bunker tunnel, crawlspace). */
  function placePlayer(g, x, y) {
    var p = g.player;
    p.w = 24; p.h = 48; p.crouch = false;
    p.x = x; p.y = y; p.vx = 0; p.vy = 0; p.sprinting = false;
    if (solidAt(g.room, p)) { p.x = x - 4; p.y = y + 24; p.w = 32; p.h = 24; p.crouch = true; }
  }

  /** The kitchen trapdoor is a platform only while it is closed. */
  function syncTrap(room) {
    var i;
    if (!room.trapProp) return;
    i = room.platforms.indexOf(room.trapPlat);
    if (trap.open > 0 && i >= 0) room.platforms.splice(i, 1);
    else if (trap.open <= 0 && i < 0) room.platforms.push(room.trapPlat);
  }

  function rescue(g, room) {
    var list = (RESCUE[room.id] || []).concat(room.rescue || []);
    list.forEach(function (r) {
      if (g.flags[r.flag] && !Z.Inventory.owned(g, r.id)) Z.Items.spawnDrop(g, r.id, r.x, r.y);
    });
  }

  /**
   * Loads a room: builds the runtime copy, places the player, resets per-visit state, then spawns enemies and items.
   * main.js calls this (via g.enterRoom) only while the screen is black, or at game start/load.
   * @param {object} g game
   * @param {string} id room id (main.js has already checked it exists)
   * @param {string|{x:number,y:number}|null} spawn named entrance, exact standing top-left, or null for the default
   */
  function enter(g, id, spawn) {
    var room = buildRoom(ROOMS[id]), name = 'default', d, pos;
    g.room = room; g.roomId = id;
    if (typeof spawn === 'string' && room.spawns[spawn]) name = spawn;
    d = room.spawns[name];
    g.entrance = { x: d.x, y: d.y };                        // where a fall respawns you and where the boss re-enters
    pos = (spawn && typeof spawn === 'object') ? spawn : d;
    cut = null; cutPending = false; g.frozen = false; g.holdP = 0;
    trap.open = 0; trap.cool = 0; valveT = 0; msgCool = 0; roomT = 0; flash = 0;
    syncTrap(room);
    placePlayer(g, pos.x, pos.y);
    if (solidAt(room, g.player)) placePlayer(g, d.x, d.y);   // a hand-edited save must never embed the player in a wall
    g.bolts = []; g.boltsRoom = id;
    Rd.clearParticles();
    Z.Enemies.populate(g, room);
    Z.Items.spawnFor(g, room);
    rescue(g, room);
  }

  /* ------------------------------------------------------------ edge exits */

  /** Toast for a blocked edge exit, at most once per second. */
  function refuse(g, need) {
    var m = need.msg || 'Nie możesz tędy przejść.';
    // DECISION: once the player carries the handle, point at the real next step instead of the "no handle" line
    if (need.used === 'valve_handle' && Z.Inventory.has(g, 'valve_handle')) m = 'Śluza jest zamknięta. Przytrzymaj [E] przy zaworze.';
    if (msgCool > 0) return;
    msgCool = 60;
    say(g, m);
    click();
  }

  /** player.js clamps x to the screen, so "pushing into the edge" = clamped position + moving that way. */
  function checkExits(g) {
    var p = g.player, cy = p.y + p.h / 2, list = g.room.exits, i, e, push, r;
    for (i = 0; i < list.length; i++) {
      e = list[i];
      if (e.kind !== 'edge') continue;
      push = e.side === 'left' ? (p.x <= 0 && p.vx < 0) : (p.x + p.w >= g.W && p.vx > 0);
      if (!push || cy < e.y0 || cy > e.y1) continue;
      r = satisfy(g, e.need);
      if (!r) { refuse(g, e.need); continue; }
      if (r === 2 && e.need.ok) say(g, e.need.ok);
      g.changeRoom(e.to, e.at || 'default');
      return;
    }
  }

  /* ------------------------------------------------------------ props: doors, stairs, ladders, hatches, machines */

  function usePass(g, pr) {
    var r = satisfy(g, pr.need);
    if (!r) { say(g, pr.need.msg || 'Zamknięte.'); click(); return; }
    if (r === 2 && pr.need.ok) say(g, pr.need.ok);
    g.changeRoom(pr.to, pr.at || 'default');
  }

  function useFusebox(g, pr) {
    if (g.flags.fuseInstalled) { say(g, 'Bezpiecznik już siedzi w skrzynce.'); return; }
    if (!Z.Inventory.consume(g, 'fuse')) { say(g, 'Skrzynka bezpieczników. Brakuje w niej bezpiecznika.'); click(); return; }
    g.flags.fuseInstalled = true;
    flash = 24;
    Z.Audio.play('pickup');
    Z.Audio.play('trapdoor', { vol: 0.3 });                 // the relay clunks home
    Rd.spark(pr.x + pr.w / 2, pr.y + 16, 14, '#8cf');
    say(g, 'Bezpiecznik wskoczył na miejsce. W kuchni zapala się światło.');
  }

  function useCrafting(g) {
    var m = Z.Inventory.craftPoison(g);
    say(g, m);
    Z.Audio.play(/^Pokryto/.test(m) ? 'pickup' : 'click');
  }

  function leverReady(g) {
    var inv = Z.Inventory;
    return !!g.flags.fuseInstalled && (inv.has(g, 'key_chute') || inv.wasUsed(g, 'key_chute')) && trap.open === 0 && trap.cool === 0;
  }

  function openTrap(g) {
    var tp = g.room.trapProp;
    trap.open = tp.open || 180;                             // spec: open for 3 s
    syncTrap(g.room);
    Z.Audio.play('trapdoor');
    Rd.shake(4, 10);
    Rd.dust(tp.x + tp.w / 2, tp.y, 18);
  }

  /** Lever needs power (fuse installed) AND the chute key; the key is spent the first time it turns. */
  function pullLever(g) {
    var inv = Z.Inventory, f = g.flags, r;
    if (trap.open > 0) { say(g, 'Zapadnia jest już otwarta.'); return; }
    if (trap.cool > 0) { say(g, 'Dźwignia jeszcze się nie zresetowała.'); click(); return; }
    if (!f.fuseInstalled) {
      say(g, (inv.has(g, 'key_chute') || inv.wasUsed(g, 'key_chute'))
        ? 'Dźwignia nie reaguje. Skrzynka bezpieczników jest martwa.'
        : 'Dźwignia jest martwa. Brakuje prądu i klucza do mechanizmu.');
      click();
      return;
    }
    r = inv.wasUsed(g, 'key_chute') ? 1 : (inv.consume(g, 'key_chute') ? 2 : 0);
    if (!r) { say(g, 'Mechanizm zsypu jest zablokowany. Potrzebny klucz.'); click(); return; }
    if (r === 2) say(g, 'Klucz pasuje do mechanizmu zsypu.');
    openTrap(g);
  }

  /** Hold-[E] valve: the progress bar is g.holdP (drawn by the HUD). @returns {boolean} true while actively turning */
  function updateValve(g, pr) {
    var inv = Z.Inventory, In = Z.Input;
    if (inv.wasUsed(g, pr.item)) return false;              // already open: nothing left to do
    g.prompt = '[E] Przytrzymaj: ' + pr.label;
    if (!In.down('interact')) return false;
    if (!inv.has(g, pr.item)) {
      if (In.pressed('interact')) { say(g, 'Zawór nie ma korby. Ktoś ją schował.'); click(); }
      return false;
    }
    valveT++;
    g.holdP = valveT / pr.hold;
    if (valveT % 24 === 1) click();                         // metal creaks as it turns
    if (valveT >= pr.hold) {
      inv.consume(g, pr.item);                              // spent: the airlock stays open for good (it is in `used`)
      Z.Audio.play('trapdoor');
      Rd.shake(5, 24);
      Rd.dust(pr.x + pr.w / 2, 640, 16);
      say(g, 'Zawór ustępuje. Śluza bunkra otwiera się z hukiem.');
      return false;
    }
    return true;
  }

  var USE = {
    door: usePass, stairs: usePass, ladder: usePass, hatch: usePass,
    chained: function (g) { say(g, 'Łańcuch nie puszcza. Za drzwiami wyje wiatr.'); click(); },   // locked for the whole chapter
    fusebox: useFusebox, crafting: useCrafting, lever: pullLever
  };

  var PROMPT = {
    chained: function () { return '[E] Drzwi wejściowe'; },
    fusebox: function (g) { return (!g.flags.fuseInstalled && Z.Inventory.has(g, 'fuse')) ? '[E] Włóż bezpiecznik' : '[E] Skrzynka bezpieczników'; },
    crafting: function (g) {
      var v = g.inv;
      return (v.poisonBottle && Z.Inventory.has(g, 'vial') && v.ammo.bolts > 0) ? '[E] Zatruj bełty' : '[E] Stół kuchenny';
    },
    lever: function (g) { return leverReady(g) ? '[E] Pociągnij dźwignię' : '[E] Dźwignia'; }
  };

  function promptFor(g, pr) { return PROMPT[pr.kind] ? PROMPT[pr.kind](g, pr) : '[E] ' + (pr.label || 'Użyj'); }

  function propBox(pr) { return { x: pr.x - PAD, y: pr.y - 20, w: pr.w + PAD * 2, h: pr.h + 40 + (pr.reach || 0) }; }

  /** The overlapping prop whose centre is closest to the player (the kitchen has three props within a few steps). */
  function nearestProp(g) {
    var p = g.player, list = g.room.props, best = null, bd = 1e9, i, pr, d;
    for (i = 0; i < list.length; i++) {
      pr = list[i];
      if (pr.kind === 'trapdoor' || !ov(p, propBox(pr))) continue;
      d = Math.abs(pr.x + pr.w / 2 - (p.x + p.w / 2));
      if (d < bd) { bd = d; best = pr; }
    }
    return best;
  }

  function updateProps(g) {
    var pr = g.prompt ? null : nearestProp(g), holding = false;   // an item prompt (set earlier this frame) wins
    if (pr) {
      if (pr.kind === 'valve') holding = updateValve(g, pr);
      else {
        g.prompt = promptFor(g, pr);
        if (Z.Input.pressed('interact') && USE[pr.kind]) USE[pr.kind](g, pr);
      }
    }
    if (!holding) { valveT = 0; g.holdP = 0; }
  }

  /* ------------------------------------------------------------ trapdoor window + steam */

  function updateTrap(g) {
    var tp = g.room.trapProp;
    if (!tp) return;
    if (trap.open > 0) {
      // DECISION: the boss is checked on every frame of the 3 s window, so a lever pulled a moment early still catches it.
      // The zone starts 4 px above the floor line because a boss standing on the plank only touches it.
      if (g.boss && ov(g.boss, { x: tp.x, y: tp.y - 4, w: tp.w, h: tp.h + 4 })) Z.Enemies.dropBoss(g);
      if (--trap.open === 0) {
        syncTrap(g.room);
        trap.cool = tp.cooldown || 480;                     // spec: lever cooldown 8 s after a miss
        Z.Audio.play('trapdoor', { vol: 0.5 });
        Rd.dust(tp.x + tp.w / 2, tp.y, 10);
      }
    } else if (trap.cool > 0) trap.cool--;
  }

  /** DECISION: each cycle starts with its off period, so a jet never fires the instant you enter the room. */
  function steamPhase(h) { return (roomT + (h.at || 0)) % (h.on + h.off); }

  function updateHazards(g) {
    var list = g.room.hazards, i, h, ph;
    for (i = 0; i < list.length; i++) {
      h = list[i];
      if (h.kind !== 'steam') continue;
      ph = steamPhase(h);
      if (ph === h.off) Z.Audio.play('knife', { vol: 0.4 });  // hiss as the jet fires
      if (ph >= h.off && ov(g.player, h)) Z.Player.hurt(g, 10);
    }
  }

  /* ------------------------------------------------------------ boss-trap cutscene */

  function endCut(g) {
    if (cut.done) return;
    g.win();                                                // returns early unless the fade can start; retried next frame
    if (g.fade.phase !== 0) cut.done = true;
  }

  /**
   * Called by enemies.js once the boss has sunk through the kitchen floor (flags.bossTrapped is already set).
   * Fades to the chute room and runs: rumble, slide down the chute, drop into the cage, the bars slam, win screen.
   * @param {object} g game
   */
  function onBossFallen(g) {
    if (cut || cutPending) return;
    cutPending = true;
    g.fadeTo(function () {
      var boss;
      cutPending = false;
      g.enterRoom('piwnica_zsyp', 'cutscene');              // resets `cut`, so ours is created afterwards
      g.room.dark = false;                                  // the work lamp over the cage clicks on
      boss = Z.Enemies.create('boss', 0, 0);
      boss.state = 'chase';
      cut = { t: 0, boss: boss, vy: 0, bx: 0, landT: 0, slamT: 0, gate: 0, done: false };
      g.frozen = true;                                      // player.js skips its update while this is set
    }, 24);
  }

  /** One cutscene step (about 5 s in total). */
  function stepCut(g) {
    var c = cut, b = c.boss, ch = g.room.chute, cg = g.room.cage, t, s;
    if (!ch || !cg) { endCut(g); return; }                  // a sequel that removed the chute room still ends in the win screen
    t = ++c.t; b.t++;
    if (t === 1) click();
    if (t < 50) {
      if (t % 8 === 0) Rd.dust(ch.x1, ch.y1 + 24, 2);        // rubble shakes loose: something is coming down
    } else if (t < 120) {
      if (t === 50) Z.Audio.play('boss');
      s = (t - 50) / 70; s *= s;                            // it accelerates down the slope
      b.x = ch.x1 + (ch.x2 - ch.x1) * s - b.w / 2;
      b.y = ch.y1 + (ch.y2 - ch.y1) * s - b.h / 2;
      if (t % 6 === 0) { Z.Audio.play('knife', { vol: 0.5 }); Rd.spark(b.x + b.w / 2, b.y + b.h / 2, 4, '#9aa'); }
      Rd.shake(2, 3);
    } else if (!c.landT) {
      c.vy += 0.6; b.y += c.vy;
      if (b.y + b.h >= cg.y + cg.h) {
        b.y = cg.y + cg.h - b.h; c.landT = t; c.bx = b.x;
        Z.Audio.play('hit'); Rd.shake(8, 12); Rd.dust(b.x + b.w / 2, cg.y + cg.h, 22);
      }
    } else if (!c.slamT) {
      if (t >= c.landT + 50) {                              // a beat of silence, then the grid drops
        c.gate = Math.min(1, c.gate + 0.15);
        if (c.gate >= 1) {
          c.slamT = t;
          Z.Audio.play('trapdoor'); Rd.shake(10, 20); Rd.dust(cg.x + cg.w / 2, cg.y + cg.h, 28);
        }
      }
    } else {
      b.x = c.bx + (t < c.slamT + 24 ? Math.sin(t * 1.7) * 4 : 0);   // it throws itself at the bars
      if (t >= c.slamT + 100) endCut(g);
    }
  }

  /* ------------------------------------------------------------ update */

  /**
   * One simulation step for the current room (main.js calls it after player, enemies and items).
   * @param {object} g game
   */
  function update(g) {
    roomT++;
    if (msgCool > 0) msgCool--;
    if (flash > 0) flash--;
    if (cut) { stepCut(g); return; }
    updateTrap(g);
    updateHazards(g);
    updateProps(g);
    if (g.fade.phase === 0) checkExits(g);                  // skipped when a prop already started a transition
  }

  /* ------------------------------------------------------------ drawing: props */

  var DRAW = {};

  /** Boards across a crowbar door, a padlock for key doors; both vanish once the item has been used. */
  function lockMark(ctx, g, pr) {
    var n = pr.need, cx = pr.x + pr.w / 2, cy = pr.y + pr.h / 2;
    if (!n || !n.item || Z.Inventory.wasUsed(g, n.item)) return;
    if (n.item === 'crowbar') {
      ctx.strokeStyle = '#6b5a3c'; ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(pr.x - 4, pr.y + 20); ctx.lineTo(pr.x + pr.w + 4, pr.y + pr.h - 30);
      ctx.moveTo(pr.x - 4, pr.y + pr.h - 30); ctx.lineTo(pr.x + pr.w + 4, pr.y + 20);
      ctx.stroke();
    } else {
      ctx.fillStyle = '#c8aa5a'; ctx.fillRect(cx - 7, cy - 4, 14, 12);
      ctx.strokeStyle = '#c8aa5a'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(cx, cy - 4, 6, Math.PI, 0); ctx.stroke();
    }
  }

  DRAW.door = function (ctx, g, pr) {
    rect(ctx, pr.x - 6, pr.y - 6, pr.w + 12, pr.h + 6, '#120d0a', '#4a3a2c');
    rect(ctx, pr.x, pr.y, pr.w, pr.h, '#3a2a1e', '#6a5440');
    ctx.fillStyle = '#2a1d14';
    ctx.fillRect(pr.x + 8, pr.y + 10, pr.w - 16, 40);
    ctx.fillRect(pr.x + 8, pr.y + 62, pr.w - 16, pr.h - 76);
    ctx.fillStyle = '#c8aa5a';
    ctx.fillRect(pr.x + pr.w - 14, pr.y + 66, 6, 6);
    lockMark(ctx, g, pr);
  };

  DRAW.stairs = function (ctx, g, pr) {
    var n = 7, sw = pr.w / n, sh = pr.h / n, up = pr.dir === 'up', i, top, grd;
    rect(ctx, pr.x, pr.y, pr.w, pr.h, '#0a0908');
    for (i = 0; i < n; i++) {                               // 'up' steps rise to the right, 'down' steps sink to the right
      top = up ? pr.y + pr.h - (i + 1) * sh : pr.y + (i + 1) * sh;
      ctx.fillStyle = '#4a4036'; ctx.fillRect(pr.x + i * sw, top, sw - 1, pr.y + pr.h - top);
      ctx.fillStyle = '#6a5c4c'; ctx.fillRect(pr.x + i * sw, top, sw - 1, 3);
    }
    grd = ctx.createLinearGradient(pr.x, 0, pr.x + pr.w, 0);   // the far end fades into the dark: where the stairs lead
    grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(0,0,0,0.8)');
    ctx.fillStyle = grd; ctx.fillRect(pr.x, pr.y, pr.w, pr.h);
    lockMark(ctx, g, pr);
  };

  DRAW.ladder = function (ctx, g, pr) {
    var y;
    ctx.fillStyle = '#5a4630';
    ctx.fillRect(pr.x + 6, pr.y, 5, pr.h);
    ctx.fillRect(pr.x + pr.w - 11, pr.y, 5, pr.h);
    for (y = pr.y + 14; y < pr.y + pr.h; y += 26) ctx.fillRect(pr.x + 6, y, pr.w - 12, 4);
  };

  DRAW.hatch = function (ctx, g, pr) {
    var locked = pr.need && pr.need.flag && !g.flags[pr.need.flag];
    rect(ctx, pr.x, pr.y, pr.w, pr.h, '#2b2118', '#6a5440');
    ctx.strokeStyle = '#a58b5a'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(pr.x + pr.w / 2, pr.y + pr.h / 2, 6, 0, Math.PI * 2); ctx.stroke();   // pull ring
    if (locked) {                                           // wedged shut until the crawler is dead
      ctx.strokeStyle = '#6b5a3c'; ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(pr.x - 4, pr.y + 4); ctx.lineTo(pr.x + pr.w + 4, pr.y + pr.h - 4);
      ctx.moveTo(pr.x - 4, pr.y + pr.h - 4); ctx.lineTo(pr.x + pr.w + 4, pr.y + 4);
      ctx.stroke();
    }
  };

  DRAW.chained = function (ctx, g, pr) {
    rect(ctx, pr.x - 8, pr.y - 8, pr.w + 16, pr.h + 8, '#0d0f14', '#3a4250');
    rect(ctx, pr.x, pr.y, pr.w, pr.h, '#23262c', '#4c5360');
    ctx.strokeStyle = 'rgba(170,210,255,' + (0.3 + 0.12 * Math.sin(g.time * 0.05)).toFixed(2) + ')';   // cold light leaking round the frame
    ctx.lineWidth = 3; ctx.strokeRect(pr.x - 2, pr.y - 2, pr.w + 4, pr.h + 2);
    ctx.strokeStyle = '#8a8f99'; ctx.lineWidth = 5; ctx.setLineDash([7, 4]);
    ctx.beginPath();
    ctx.moveTo(pr.x, pr.y + 20); ctx.lineTo(pr.x + pr.w, pr.y + pr.h - 20);
    ctx.moveTo(pr.x + pr.w, pr.y + 20); ctx.lineTo(pr.x, pr.y + pr.h - 20);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#c8aa5a'; ctx.fillRect(pr.x + pr.w / 2 - 8, pr.y + pr.h / 2 - 6, 16, 14);   // padlock where the chains cross
  };

  DRAW.fusebox = function (ctx, g, pr) {
    var on = g.flags.fuseInstalled;
    rect(ctx, pr.x, pr.y, pr.w, pr.h, '#2c3036', '#5b626b');
    rect(ctx, pr.x + 5, pr.y + 6, pr.w - 10, pr.h - 24, '#101215');
    if (on) { ctx.fillStyle = '#d8c24a'; ctx.fillRect(pr.x + pr.w / 2 - 4, pr.y + 10, 8, 18); }
    ctx.save();
    ctx.shadowColor = on ? '#3fd45a' : '#d33'; ctx.shadowBlur = 6;
    ctx.fillStyle = on ? '#3fd45a' : (((g.time >> 4) & 1) ? '#d33' : '#511');   // red blink = no fuse
    ctx.fillRect(pr.x + pr.w - 12, pr.y + pr.h - 12, 6, 6);
    ctx.restore();
  };

  DRAW.crafting = function (ctx, g, pr) {
    ctx.fillStyle = '#5a4630'; ctx.fillRect(pr.x, pr.y, pr.w, 10);                                   // tabletop
    ctx.fillStyle = '#3a2d20';
    ctx.fillRect(pr.x + 6, pr.y + 10, 8, pr.h - 10); ctx.fillRect(pr.x + pr.w - 14, pr.y + 10, 8, pr.h - 10);
    ctx.fillStyle = '#9ad23a'; ctx.fillRect(pr.x + 12, pr.y - 16, 9, 16);                           // poison bottle
    ctx.fillStyle = '#6ad0d8'; ctx.fillRect(pr.x + 32, pr.y - 12, 7, 12);                           // vial
    ctx.strokeStyle = '#c9b79c'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(pr.x + 50, pr.y - 3); ctx.lineTo(pr.x + 78, pr.y - 3); ctx.stroke();   // a loose bolt
  };

  DRAW.lever = function (ctx, g, pr) {
    var powered = g.flags.fuseInstalled, open = trap.open > 0, cd = trap.cool > 0, lamp;
    rect(ctx, pr.x - 8, pr.y + 30, pr.w + 16, 18, '#2a2d33', '#5b626b');
    ctx.save();
    ctx.translate(pr.x + pr.w / 2, pr.y + 34);
    ctx.rotate(open ? 0.95 : -0.95);                        // thrown over while the trapdoor is open
    ctx.fillStyle = '#6b6f78'; ctx.fillRect(-3, -38, 6, 38);
    ctx.fillStyle = '#a02828'; ctx.beginPath(); ctx.arc(0, -40, 7, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    lamp = !powered ? '#3a1010' : (cd ? (((g.time >> 3) & 1) ? '#d33' : '#511') : (open ? '#e8c040' : '#3fd45a'));
    ctx.fillStyle = lamp; ctx.fillRect(pr.x + 8, pr.y + 12, 8, 8);   // status lamp: dead / ready / open / cooling down
  };

  DRAW.valve = function (ctx, g, pr) {
    var done = Z.Inventory.wasUsed(g, pr.item), prog = valveT / pr.hold, cx = pr.x + pr.w / 2, dx = pr.x + pr.w + 4, i, a;
    rect(ctx, dx, 619, 1280 - dx, 31, done ? '#030304' : '#3a4048', done ? null : '#6a727c');   // airlock door at the end of the tunnel
    if (!done) {
      ctx.fillStyle = '#8a929c';
      ctx.fillRect(dx + 8, 624, 3, 3); ctx.fillRect(dx + 8, 640, 3, 3); ctx.fillRect(dx + 26, 624, 3, 3); ctx.fillRect(dx + 26, 640, 3, 3);
    }
    ctx.save();
    ctx.translate(cx, 634);
    ctx.rotate(done ? 2.4 : prog * 6);
    ctx.strokeStyle = '#8a8f99'; ctx.lineWidth = 3;
    a = (done || prog > 0) ? 12 : 5;                        // no handle yet: only the stubs of the spokes
    ctx.beginPath();
    for (i = 0; i < 4; i++) { ctx.moveTo(0, 0); ctx.lineTo(Math.cos(i * Math.PI / 2) * a, Math.sin(i * Math.PI / 2) * a); }
    ctx.stroke();
    if (done || prog > 0) { ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI * 2); ctx.stroke(); }
    ctx.restore();
    ctx.fillStyle = '#5a5f68'; ctx.beginPath(); ctx.arc(cx, 634, 4, 0, Math.PI * 2); ctx.fill();
  };

  /* ------------------------------------------------------------ drawing: room, trapdoor, steam, cage */

  function drawTrap(ctx, g, room) {
    var tp = room.trapProp, x = tp.x, y = tp.y, w = tp.w, h = tp.h, i, grd;
    if (trap.open > 0) {
      grd = ctx.createLinearGradient(0, y, 0, y + h);
      grd.addColorStop(0, '#000'); grd.addColorStop(1, '#1a0a08');
      ctx.fillStyle = grd; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#4a3a2a';                            // the two flaps hang from their hinges
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 22, y); ctx.lineTo(x + 4, y + 52); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(x + w, y); ctx.lineTo(x + w - 22, y); ctx.lineTo(x + w - 4, y + 52); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,200,120,' + (0.10 + 0.05 * Math.sin(roomT * 0.3)).toFixed(3) + ')';   // a faint glow rises from the pit
      ctx.fillRect(x, y, w, 8);
    } else {
      ctx.fillStyle = '#3e3126'; ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = '#2a2018'; ctx.lineWidth = 2;
      for (i = 1; i < 6; i++) { ctx.beginPath(); ctx.moveTo(x + i * w / 6, y); ctx.lineTo(x + i * w / 6, y + h); ctx.stroke(); }
      ctx.strokeStyle = '#6a5440'; ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
      ctx.fillStyle = '#8a8f99'; ctx.fillRect(x + 8, y + 3, 14, 5); ctx.fillRect(x + w - 22, y + 3, 14, 5);   // hinges
      ctx.fillStyle = '#9a1f1f';                            // warning stripes along the lip: this is not an ordinary floor
      for (i = 0; i < w; i += 40) ctx.fillRect(x + i + 8, y, 18, 3);
    }
  }

  /** The kitchen's ceiling lamp only works once the fuse is in. */
  function drawLamp(ctx, g) {
    var on = !!g.flags.fuseInstalled, f = on ? 0.9 + 0.1 * Math.sin(g.time * 0.7) * Math.sin(g.time * 0.23) : 0, grd;
    ctx.fillStyle = '#2a2a2e'; ctx.fillRect(639, 40, 2, 22);
    ctx.fillStyle = on ? '#e8d48a' : '#3a3a3e'; ctx.fillRect(626, 62, 28, 9);
    if (!on) return;
    grd = ctx.createRadialGradient(640, 72, 10, 640, 72, 480);
    grd.addColorStop(0, 'rgba(255,214,140,' + (0.3 * f).toFixed(3) + ')');
    grd.addColorStop(1, 'rgba(255,214,140,0)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, g.W, g.H);
  }

  function drawSteam(ctx, h) {
    var ph = steamPhase(h), on = ph >= h.off, warn = !on && ph >= h.off - 45, cx = h.x + h.w / 2, base = h.y + h.h, i, k, a;
    ctx.fillStyle = '#2a2a2e'; ctx.fillRect(h.x + 6, base - 4, h.w - 12, 4);        // the floor vent
    if (!on && !warn) return;                               // a few wisps in the last 0.75 s warn the player
    for (i = 0; i < (on ? 12 : 3); i++) {
      k = ((roomT * (on ? 3 : 1.2) + i * 13) % h.h) / h.h;  // 0 at the vent, 1 at the top of the jet
      a = (on ? 0.5 : 0.25) * (1 - k);
      ctx.fillStyle = 'rgba(232,234,240,' + a.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(cx + Math.sin(roomT * 0.12 + i * 1.7) * 9 * k, base - k * (on ? h.h : 40), 8 + k * 14, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  /** A dark gradient at each walk-off edge hints at the doorway; it turns red while the exit is locked. */
  function drawExits(ctx, g, room) {
    room.exits.forEach(function (e) {
      var left = e.side === 'left', locked = e.need && !isOpen(g, e.need), x0 = left ? 0 : g.W, x1 = left ? 46 : g.W - 46, grd;
      grd = ctx.createLinearGradient(x0, 0, x1, 0);
      grd.addColorStop(0, locked ? 'rgba(60,0,0,0.75)' : 'rgba(0,0,0,0.7)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd;
      ctx.fillRect(left ? 0 : g.W - 46, e.y0, 46, Math.min(e.y1, 650) - e.y0);
    });
  }

  function drawChute(ctx, ch) {
    var dx = ch.x2 - ch.x1, dy = ch.y2 - ch.y1, len = Math.sqrt(dx * dx + dy * dy);
    var nx = dy / len * ch.w / 2, ny = -dx / len * ch.w / 2, i, f;
    ctx.beginPath();
    ctx.moveTo(ch.x1 + nx, ch.y1 + ny); ctx.lineTo(ch.x1 - nx, ch.y1 - ny);
    ctx.lineTo(ch.x2 - nx, ch.y2 - ny); ctx.lineTo(ch.x2 + nx, ch.y2 + ny);
    ctx.closePath();
    ctx.fillStyle = '#0c0e12'; ctx.fill();
    ctx.strokeStyle = '#3a424c'; ctx.lineWidth = 4; ctx.stroke();
    ctx.strokeStyle = 'rgba(90,100,112,0.35)'; ctx.lineWidth = 2;   // riveted seams across the tube
    for (i = 1; i < 8; i++) {
      f = i / 8;
      ctx.beginPath();
      ctx.moveTo(ch.x1 + dx * f + nx, ch.y1 + dy * f + ny); ctx.lineTo(ch.x1 + dx * f - nx, ch.y1 + dy * f - ny);
      ctx.stroke();
    }
  }

  /** gate 0 = bars raised out of sight, 1 = slammed shut in front of the cage. */
  function drawCage(ctx, cg, gate) {
    var i, by;
    ctx.fillStyle = '#4a5058';
    ctx.fillRect(cg.x - 8, cg.y - 8, cg.w + 16, 12);                                      // top beam
    ctx.fillRect(cg.x - 8, cg.y, 10, cg.h); ctx.fillRect(cg.x + cg.w - 2, cg.y, 10, cg.h);   // posts
    ctx.save();
    ctx.beginPath(); ctx.rect(cg.x, cg.y, cg.w, cg.h); ctx.clip();                        // the front grid drops in from above
    by = cg.y - (1 - gate) * cg.h;
    ctx.fillStyle = '#6a717b';
    for (i = 0; i <= cg.w; i += 24) ctx.fillRect(cg.x + i, by, 6, cg.h);
    ctx.fillRect(cg.x, by + cg.h / 3, cg.w, 5); ctx.fillRect(cg.x, by + cg.h * 2 / 3, cg.w, 5); ctx.fillRect(cg.x, by + cg.h - 6, cg.w, 6);
    ctx.restore();
  }

  function drawZsyp(ctx, g, room) {
    var cg = room.cage, gate = cut ? cut.gate : (g.flags.bossTrapped ? 1 : 0), boss = null, grd, fl;
    drawChute(ctx, room.chute);
    ctx.fillStyle = '#07080b'; ctx.fillRect(cg.x, cg.y, cg.w, cg.h);                      // inside of the cage
    if (cut) { if (cut.t >= 50) boss = cut.boss; }
    else if (g.flags.bossTrapped) {                                                        // a save that loads after the trap
      if (!staticBoss) { staticBoss = Z.Enemies.create('boss', cg.x + 70, cg.y + cg.h - 90); staticBoss.state = 'chase'; }
      staticBoss.t = g.time;
      boss = staticBoss;
    }
    if (boss) Z.Enemies.ENEMIES.boss.draw(ctx, g, boss);
    drawCage(ctx, cg, gate);
    if (cut) {                                                                              // work lamp over the cage
      fl = 0.16 + 0.04 * Math.sin(cut.t * 0.9);
      grd = ctx.createRadialGradient(cg.x + cg.w / 2, cg.y - 60, 20, cg.x + cg.w / 2, cg.y - 60, 420);
      grd.addColorStop(0, 'rgba(255,210,140,' + (fl + 0.12).toFixed(3) + ')');
      grd.addColorStop(1, 'rgba(255,210,140,0)');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, g.W, g.H);
    }
  }

  /** Cached top-to-bottom shading that gives every flat room a little depth. */
  function shade(ctx, g) {
    if (!shadeGrad) {
      shadeGrad = ctx.createLinearGradient(0, 0, 0, g.H);
      shadeGrad.addColorStop(0, 'rgba(0,0,0,0.35)');
      shadeGrad.addColorStop(0.5, 'rgba(0,0,0,0)');
      shadeGrad.addColorStop(1, 'rgba(0,0,0,0.3)');
    }
    ctx.fillStyle = shadeGrad;
    ctx.fillRect(0, 0, g.W, g.H);
  }

  /**
   * Draws the room: background, deco, platforms (filled, with a 2 px lighter stroke), exit hints, props, hazards.
   * Pure drawing: it never changes game state, because paused/journal/win screens call it too.
   * @param {CanvasRenderingContext2D} ctx
   * @param {object} g game
   */
  function draw(ctx, g) {
    var room = g.room, fg = room.fg || '#333333', i, d, r, pr;
    ctx.save();
    ctx.fillStyle = room.bgColor || '#101010';
    ctx.fillRect(0, 0, g.W, g.H);
    shade(ctx, g);
    for (i = 0; i < room.deco.length; i++) {
      d = room.deco[i];
      ctx.fillStyle = d[4]; ctx.fillRect(d[0], d[1], d[2], d[3]);
      ctx.strokeStyle = lighten(d[4], 14); ctx.lineWidth = 1; ctx.strokeRect(d[0] + 0.5, d[1] + 0.5, d[2] - 1, d[3] - 1);
    }
    if (room.trapProp) drawLamp(ctx, g);
    ctx.fillStyle = fg; ctx.strokeStyle = lighten(fg, 30); ctx.lineWidth = 2;
    for (i = 0; i < room.platforms.length; i++) {
      r = room.platforms[i];
      if (r === room.trapPlat) continue;                    // the trapdoor draws itself
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
    }
    drawExits(ctx, g, room);
    if (room.trapProp) drawTrap(ctx, g, room);
    for (i = 0; i < room.props.length; i++) { pr = room.props[i]; if (DRAW[pr.kind]) DRAW[pr.kind](ctx, g, pr); }
    for (i = 0; i < room.hazards.length; i++) if (room.hazards[i].kind === 'steam') drawSteam(ctx, room.hazards[i]);
    if (room.cage) drawZsyp(ctx, g, room);
    if (room.trapProp && !g.flags.fuseInstalled) { ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.fillRect(0, 0, g.W, g.H); }   // no power yet
    if (flash > 0) { ctx.fillStyle = 'rgba(190,220,255,' + (flash / 24 * 0.35).toFixed(3) + ')'; ctx.fillRect(0, 0, g.W, g.H); }
    ctx.restore();
  }

  Z.Rooms = { ROOMS: ROOMS, registerRoom: registerRoom, enter: enter, update: update, draw: draw, onBossFallen: onBossFallen };
})(window.ZSYP = window.ZSYP || {});