// FILE: js/render.js
/*
 * Small shared helpers: AABB overlap, maths, screen shake, particles, the darkness vignette, text.
 */
(function (Z) {
  'use strict';

  var MAX_PARTICLES = 300;
  var particles = [];
  var shakePx = 0, shakeT = 0, shakeLen = 1;
  var off = { x: 0, y: 0 };               // reused every frame to avoid garbage

  /** @returns {number} random float in [a, b) */
  function rand(a, b) { return a + Math.random() * (b - a); }
  /** @returns {number} v limited to [lo, hi] */
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  /** AABB overlap for any two {x,y,w,h} objects. */
  function overlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  /**
   * Starts a screen shake (spec: 8 px for 10 frames on a hit).
   * @param {number} px peak offset in pixels
   * @param {number} frames duration in simulation frames
   */
  function shake(px, frames) { shakePx = px; shakeT = shakeLen = frames; }

  /** @returns {{x:number,y:number}} this frame's camera offset; decays linearly so the hit "settles". */
  function shakeOffset() {
    if (shakeT <= 0) { off.x = 0; off.y = 0; return off; }
    var k = shakePx * shakeT / shakeLen;
    off.x = rand(-k, k); off.y = rand(-k, k);
    return off;
  }

  function burst(x, y, n, o) {
    for (var i = 0; i < n && particles.length < MAX_PARTICLES; i++) {
      var a = rand(0, Math.PI * 2), s = rand(0.3, 1) * o.speed;
      particles.push({
        x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - (o.up || 0),
        life: o.life, max: o.life, size: rand(o.size * 0.6, o.size), grav: o.grav, color: o.color
      });
    }
  }

  /** Hit sparks. @param {string} [color] CSS colour (default warm white) */
  function spark(x, y, n, color) {
    burst(x, y, n || 8, { color: color || '#ffd9a0', speed: 4, life: 18, size: 3, grav: 0.2 });
  }

  /** Slow brown dust cloud (boss-trap sequence). */
  function dust(x, y, n) {
    burst(x, y, n || 24, { color: '#6b5b4a', speed: 2.2, life: 50, size: 7, grav: -0.01, up: 1 });
  }

  /** Advances particles and the shake timer; main.js calls this every playing step. */
  function updateParticles() {
    if (shakeT > 0) shakeT--;
    for (var i = particles.length - 1; i >= 0; i--) {
      var p = particles[i];
      p.x += p.vx; p.y += p.vy; p.vy += p.grav; p.vx *= 0.96;
      if (--p.life <= 0) particles.splice(i, 1);
    }
  }

  function drawParticles(ctx) {
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      ctx.globalAlpha = p.life / p.max;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    ctx.globalAlpha = 1;
  }

  /** Drops all particles (call from Rooms.enter so sparks don't follow the player through a door). */
  function clearParticles() { particles.length = 0; shakeT = 0; }

  /**
   * Darkness for rooms with `dark: true`: a radial hole of light around the player, black beyond it.
   * The gradient's last colour extends past the radius, so one full-screen fillRect darkens everything else.
   */
  function vignette(ctx, g) {
    var p = g.player, cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    // DECISION: flashlight on = the specified 220 px; off = 70 px, so a dark room without light is almost blind
    var r = p.flashlightOn ? 220 : 70;
    if (p.flashlightOn && p.battery < 20) r -= rand(0, 30);   // a dying battery flickers
    var grd = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r);
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, 'rgba(0,0,0,0.97)');                  // 3% leak keeps a ghost of the room visible
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, g.W, g.H);
  }

  /** One-line text helper (Georgia has all Polish diacritics on every desktop OS). */
  function text(ctx, s, x, y, size, color, align) {
    ctx.font = size + 'px Georgia, "Times New Roman", serif';
    ctx.textAlign = align || 'left';
    ctx.fillStyle = color || '#ddd';
    ctx.fillText(s, x, y);
  }

  Z.Render = {
    rand: rand, clamp: clamp, overlap: overlap,
    shake: shake, shakeOffset: shakeOffset,
    spark: spark, dust: dust, updateParticles: updateParticles, drawParticles: drawParticles, clearParticles: clearParticles,
    vignette: vignette, text: text
  };
})(window.ZSYP = window.ZSYP || {});