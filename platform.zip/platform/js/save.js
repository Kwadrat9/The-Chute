// FILE: js/save.js
/*
 * localStorage save/load under the key zsyp_save_v1. The format is the one in the spec plus two additive fields,
 * "taken" (pickups already collected, so nothing respawns) and "weapon", so loading restores exactly what you had.
 * If localStorage is blocked (private windows, strict file:// policies) the save falls back to memory for this session.
 */
(function (Z) {
  'use strict';

  var KEY = 'zsyp_save_v1';
  var STAND_W = 24, STAND_H = 48;          // must match player.js
  var mem = null;                          // newest raw save of this session (also the fallback store)
  var cacheRaw = null, cacheData = null;   // one-entry parse cache: the menus ask has() every frame

  function getRaw() {
    if (mem !== null) return mem;
    try { return window.localStorage.getItem(KEY); } catch (e) { return null; }
  }

  /** Builds the save object. Position is stored as the standing top-left, so a save made while crouched reloads cleanly. */
  function snapshot(g) {
    var p = g.player, v = g.inv, f = g.flags;
    return {
      version: 1,
      hp: Math.round(p.hp),
      stamina: Math.round(p.stamina),
      battery: Math.round(p.battery * 10) / 10,
      flashlightOn: p.flashlightOn,
      inventory: v.items.slice(),
      ammo: { bolts: v.ammo.bolts, poisoned: v.ammo.poisoned },
      weaponsOwned: v.weapons.slice(),
      poisonBottle: v.poisonBottle,
      notesCollected: v.notes.slice(),
      itemsUsed: v.used.slice(),
      fuseInstalled: f.fuseInstalled,
      crawlerDead: f.crawlerDead,
      tarantulaDead: f.tarantulaDead,
      bossProvoked: f.bossProvoked,
      bossTrapped: f.bossTrapped,
      room: g.roomId,
      playerX: Math.round(p.x + p.w / 2 - STAND_W / 2),
      playerY: Math.round(p.y + p.h - STAND_H),
      taken: v.taken.slice(),              // DECISION: additive fields, ignored by any reader of the original format
      weapon: p.weapon
    };
  }

  /**
   * Writes the save. The in-memory copy is always updated, so loading works this session even if the disk write fails.
   * @returns {boolean} true only if it reached localStorage
   */
  function write(g) {
    var raw;
    try { raw = JSON.stringify(snapshot(g)); } catch (e) { return false; }
    mem = raw;
    try { window.localStorage.setItem(KEY, raw); return true; } catch (e2) { return false; }
  }

  function parse(raw) {
    var d = null;
    if (raw === cacheRaw) return cacheData;
    try {
      d = JSON.parse(raw);
      if (!d || typeof d !== 'object' || d.version !== 1 || typeof d.room !== 'string') d = null;
    } catch (e) { d = null; }
    cacheRaw = raw; cacheData = d;
    return d;
  }

  /** @returns {object|null} the validated save, or null if there is none or it is corrupt (never throws) */
  function read() {
    var raw = getRaw();
    return raw === null ? null : parse(raw);
  }

  /** @returns {boolean} true if a loadable save exists */
  function has() { return read() !== null; }

  /** Deletes the save (not used by the menus; handy for debugging and for a sequel's "new game+"). */
  function clear() {
    mem = null; cacheRaw = null; cacheData = null;
    try { window.localStorage.removeItem(KEY); } catch (e) { /* nothing to remove */ }
  }

  function num(v, def, lo, hi) { v = Number(v); return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def; }
  function strs(a) { return Array.isArray(a) ? a.filter(function (s) { return typeof s === 'string'; }) : []; }

  /**
   * Restores a validated save into g, then enters the saved room. Every field is range-checked, so a hand-edited
   * or half-written save still loads. main.js has already called Inventory.reset and Player.create.
   * @param {object} g game
   * @param {object} d object from read()
   */
  function apply(g, d) {
    var p = g.player, v = g.inv, f = g.flags, a = d.ammo || {};
    var items = strs(d.inventory), weapons = strs(d.weaponsOwned), bolts = Math.round(num(a.bolts, 0, 0, 10));

    p.hp = num(d.hp, 100, 1, 100);
    p.stamina = num(d.stamina, 100, 0, 100);
    p.battery = num(d.battery, 100, 0, 100);
    p.flashlightOn = d.flashlightOn === true && p.battery > 0 && items.indexOf('flashlight') >= 0;

    // The spec's example lists the crossbow under "inventory"; here it is a weapon, so accept it from either place.
    if (items.indexOf('crossbow') >= 0 && weapons.indexOf('crossbow') < 0) weapons.push('crossbow');
    v.items = items.filter(function (s) { return s !== 'crossbow'; }).slice(0, Z.Inventory.SLOTS);
    v.weapons = weapons.indexOf('crossbow') >= 0 ? ['knife', 'crossbow'] : ['knife'];
    v.ammo = { bolts: bolts, poisoned: Math.min(bolts, Math.round(num(a.poisoned, 0, 0, 10))) };
    v.poisonBottle = d.poisonBottle === true;
    v.notes = strs(d.notesCollected);
    v.used = strs(d.itemsUsed);
    v.taken = strs(d.taken);               // older saves lack it; Inventory.owned() still covers items, used, notes and weapons
    p.weapon = d.weapon === 'crossbow' && v.weapons.indexOf('crossbow') >= 0 ? 'crossbow' : 'knife';

    f.fuseInstalled = d.fuseInstalled === true;
    f.crawlerDead = d.crawlerDead === true;
    f.tarantulaDead = d.tarantulaDead === true;
    f.bossProvoked = d.bossProvoked === true;
    f.bossTrapped = d.bossTrapped === true;

    g.enterRoom(d.room, (typeof d.playerX === 'number' && isFinite(d.playerX) && typeof d.playerY === 'number' && isFinite(d.playerY))
      ? { x: d.playerX, y: d.playerY } : null);
  }

  Z.Save = { KEY: KEY, snapshot: snapshot, write: write, read: read, has: has, clear: clear, apply: apply };
})(window.ZSYP = window.ZSYP || {});