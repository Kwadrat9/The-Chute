// FILE: js/player.js
/*
 * Player entity: input -> movement, platformer physics (AABB vs rectangle platforms), crouch, stamina,
 * flashlight, weapons (knife + crossbow bolts), damage and drawing.
 * p.x / p.y is the top-left corner. Standing 24x48, crouched 32x24 (feet stay planted when toggling).
 */
(function (Z) {
  'use strict';

  var GRAVITY = 0.6, JUMP = -11.5, TERMINAL = 16;
  var WALK = 3.2, SPRINT = 5.4;
  var STAND_W = 24, STAND_H = 48, CROUCH_W = 32, CROUCH_H = 24;
  var KNIFE = { dmg: 15, reach: 40, cd: 24 };         // 400 ms at 60 Hz
  var CROSSBOW = { dmg: 25, speed: 15, cd: 54 };      // 900 ms at 60 Hz
  var DOUBLE_TAP = 14;                                 // frames allowed between the two taps that start a sprint

  function ov(a, b) { return Z.Render.overlap(a, b); }

  /** @returns {boolean} true if inventory holds the item id */
  function hasItem(g, id) { return g.inv.items.indexOf(id) >= 0; }

  /** @returns {object} a fresh player with spec starting values */
  function create() {
    return {
      x: 640, y: 500, w: STAND_W, h: STAND_H, vx: 0, vy: 0, face: 1, onGround: false, crouch: false,
      hp: 100, stamina: 100, battery: 100, flashlightOn: false, iframes: 0, slowT: 0,
      weapon: 'knife', cd: 0, swing: 0, stepT: 0, sprinting: false, tapDir: 0, tapT: 0
    };
  }

  function hitsSolid(g, box) {
    var plats = g.room.platforms;
    for (var i = 0; i < plats.length; i++) if (ov(box, plats[i])) return true;
    return false;
  }

    /** Switching to standing is refused when a ceiling is in the way, which is how low tunnels force a crouch.
   *  Crouching widens the box by 8 px, so it tries centred, then flush-left, then flush-right, and refuses if a wall blocks all three. */
  function setCrouch(g, p, want) {
    if (want === p.crouch) return;
    var box, k, xs;
    if (want) {
      box = { x: 0, y: p.y + STAND_H - CROUCH_H, w: CROUCH_W, h: CROUCH_H };
      xs = [p.x - 4, p.x, p.x - 8];
      for (k = 0; k < xs.length; k++) {
        box.x = xs[k];
        if (!hitsSolid(g, box)) { p.x = box.x; p.y = box.y; p.w = CROUCH_W; p.h = CROUCH_H; p.crouch = true; return; }
      }
    } else {
      box = { x: p.x + (CROUCH_W - STAND_W) / 2, y: p.y + p.h - STAND_H, w: STAND_W, h: STAND_H };
      if (hitsSolid(g, box)) return;
      p.x = box.x; p.y = box.y; p.w = STAND_W; p.h = STAND_H; p.crouch = false;
    }
  }

  /** Axis-separated movement: resolve X first, then Y, so walls and floors never fight each other. */
  function move(g, p) {
    var plats = g.room.platforms, i, r;
    p.x += p.vx;
    for (i = 0; i < plats.length; i++) {
      r = plats[i];
      if (ov(p, r)) {
        if (p.vx > 0) p.x = r.x - p.w;
        else if (p.vx < 0) p.x = r.x + r.w;
      }
    }
    p.vy = Math.min(p.vy + GRAVITY, TERMINAL);
    p.y += p.vy;
    p.onGround = false;
    for (i = 0; i < plats.length; i++) {
      r = plats[i];
      if (ov(p, r)) {
        if (p.vy > 0) { p.y = r.y - p.h; p.onGround = true; }
        else if (p.vy < 0) p.y = r.y + r.h;
        p.vy = 0;
      }
    }
  }

  function attack(g, p) {
    var inv = g.inv;
    if (p.weapon === 'knife') {
      p.cd = KNIFE.cd; p.swing = 8;
      Z.Audio.play('knife');
      var hb = { x: p.face > 0 ? p.x + p.w : p.x - KNIFE.reach, y: p.y, w: KNIFE.reach, h: p.h };
      g.enemies.forEach(function (e) {
        if (e.dead || !ov(hb, e)) return;
        Z.Enemies.damage(g, e, KNIFE.dmg, null);        // the boss ignores the damage and only wakes up
        Z.Render.spark(e.x + e.w / 2, e.y + e.h / 2, 8);
        Z.Audio.play('hit');
      });
    } else if (inv.ammo.bolts > 0) {
      var poison = inv.ammo.poisoned > 0;               // the next N bolts are the poisoned ones
      inv.ammo.bolts--;
      if (poison) inv.ammo.poisoned--;
      p.cd = CROSSBOW.cd;
      // DECISION: bolts fly horizontally in the facing direction; no aiming mechanic beyond the spec
      g.bolts.push({ x: p.face > 0 ? p.x + p.w : p.x, y: p.y + (p.crouch ? 8 : 18), vx: p.face * CROSSBOW.speed, poison: poison });
      Z.Audio.play('crossbow');
    } else {
      p.cd = 20;
      Z.Audio.play('click');                            // an empty crossbow is its own kind of terror
    }
  }

  function control(g, p, In) {
    var dir = (In.down('right') ? 1 : 0) - (In.down('left') ? 1 : 0);
    var forced = !!g.room.crouchOnly;                   // poddasze / bunkier: crouched, no jumping

    if (g.inv.weapons.indexOf(p.weapon) < 0) p.weapon = 'knife';   // e.g. after loading an odd save
    setCrouch(g, p, forced || In.down('crouch'));

    // DECISION: the spec gives a sprint speed but no sprint key, so double-tap a direction and keep holding it
    var tapped = dir !== 0 && In.pressed(dir > 0 ? 'right' : 'left');
    if (tapped) {
      if (p.tapDir === dir && p.tapT > 0 && p.stamina > 20 && !p.crouch) p.sprinting = true;
      p.tapDir = dir; p.tapT = DOUBLE_TAP;
    }
    if (p.tapT > 0) p.tapT--;
    if (p.sprinting && (dir !== p.tapDir || p.stamina <= 0 || p.crouch)) p.sprinting = false;

    var speed = p.crouch ? WALK * 0.5 : (p.sprinting ? SPRINT : WALK);
    if (p.slowT > 0) { speed *= 0.5; p.slowT--; }       // DECISION: tarantula web slow = half speed for its duration
    p.vx = dir * speed;
    if (dir) p.face = dir;

    if (p.sprinting) p.stamina = Math.max(0, p.stamina - 1);
    else if (p.onGround) p.stamina = Math.min(100, p.stamina + 0.6);

    if (In.pressed('jump') && p.onGround && !p.crouch && !forced) {
      p.vy = JUMP; p.onGround = false;
      Z.Audio.play('jump');
    }

    if (p.onGround && dir) {                            // footsteps by distance walked, so sprinting sounds faster
      p.stepT += Math.abs(p.vx);
      if (p.stepT >= 70) { p.stepT = 0; Z.Audio.play('footstep', { vol: p.crouch ? 0.35 : 1 }); }
    }

    if (In.pressed('flashlight') && hasItem(g, 'flashlight') && (p.flashlightOn || p.battery > 0)) {
      p.flashlightOn = !p.flashlightOn;
      Z.Audio.play('click');
    }
    if (p.flashlightOn) {                               // 1 point per 300 frames
      p.battery -= 1 / 300;
      if (p.battery <= 0) { p.battery = 0; p.flashlightOn = false; }
    }

    if (In.pressed('cycle') && g.inv.weapons.length > 1) {
      var w = g.inv.weapons;
      p.weapon = w[(w.indexOf(p.weapon) + 1) % w.length];
      Z.Audio.play('click');
    }
    if (p.cd > 0) p.cd--;
    if (p.swing > 0) p.swing--;
    if (In.down('attack') && p.cd === 0) attack(g, p);
  }

  /** Moves bolts, stops them on walls, and applies hits through Z.Enemies.damage. */
  function updateBolts(g) {
    for (var i = g.bolts.length - 1; i >= 0; i--) {
      var b = g.bolts[i], gone = false;
      b.x += b.vx;
      var box = { x: b.x - 7, y: b.y - 2, w: 14, h: 4 };
      if (b.x < -20 || b.x > g.W + 20) gone = true;
      else if (hitsSolid(g, box)) { Z.Render.spark(b.x, b.y, 4, '#aaa'); gone = true; }
      else {
        for (var j = 0; j < g.enemies.length; j++) {
          var e = g.enemies[j];
          if (e.dead || !ov(box, e)) continue;
          Z.Enemies.damage(g, e, CROSSBOW.dmg, { poison: b.poison });
          Z.Render.spark(b.x, b.y, 8, b.poison ? '#7f7' : undefined);
          Z.Audio.play('hit');
          gone = true;
          break;
        }
      }
      if (gone) g.bolts.splice(i, 1);
    }
  }

  /** One simulation step. */
  function update(g) {
    var p = g.player;
    if (g.frozen) return;
    if (!g.bolts || g.boltsRoom !== g.roomId) { g.bolts = []; g.boltsRoom = g.roomId; }   // bolts never cross rooms
    control(g, p, Z.Input);
    move(g, p);
    p.x = Z.Render.clamp(p.x, 0, g.W - p.w);            // exits are detected by Rooms at x == 0 / x + w == W
    if (p.iframes > 0) p.iframes--;
    if (p.y > g.H + 60) g.respawn(g.room.fallFade || 18);   // fell out of the room: 300 ms fade (kuchnia sets fallFade = 30)
    updateBolts(g);
  }

  /**
   * Applies damage with the spec's 60-frame i-frames.
   * @param {object} g game
   * @param {number} dmg zombie 15, crawler 20, tarantula 10, web 8, boss 100
   */
  function hurt(g, dmg) {
    var p = g.player;
    if (g.dyingT > 0) return;
    if (p.iframes > 0 && dmg < 100) return;             // DECISION: boss contact (100) ignores i-frames; death must be reliable
    p.hp = Math.max(0, p.hp - dmg);
    p.iframes = 60;
    Z.Render.shake(8, 10);
    Z.Render.spark(p.x + p.w / 2, p.y + p.h / 2, 10, '#a22');
    Z.Audio.play('hit');
    if (p.hp <= 0) g.die();
  }

  /** Tarantula web debuff. @param {number} frames duration (60 = 1 s) */
  function slow(g, frames) { g.player.slowT = Math.max(g.player.slowT, frames); }

  function drawBolts(ctx, g) {
    ctx.lineWidth = 2;
    for (var i = 0; i < g.bolts.length; i++) {
      var b = g.bolts[i], s = b.vx > 0 ? 1 : -1;
      ctx.strokeStyle = b.poison ? '#8f8' : '#c9b79c';
      ctx.beginPath();
      ctx.moveTo(b.x - 8 * s, b.y);
      ctx.lineTo(b.x + 6 * s, b.y);
      ctx.stroke();
    }
  }

  /** Draws bolts, then the player as a shaded silhouette with a directional eye. */
  function draw(ctx, g) {
    var p = g.player, x = p.x, y = p.y, f = p.face;
    drawBolts(ctx, g);
    if (p.iframes > 0 && ((p.iframes >> 2) & 1)) return;      // flicker while invulnerable

    var grd = ctx.createLinearGradient(x, 0, x + p.w, 0);     // lit side faces the way we look
    grd.addColorStop(f > 0 ? 0 : 1, '#1a1d24');
    grd.addColorStop(f > 0 ? 1 : 0, '#3b4252');
    ctx.fillStyle = grd;
    ctx.fillRect(x, y, p.w, p.h);
    ctx.strokeStyle = '#596075';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, p.w - 1, p.h - 1);

    ctx.fillStyle = '#e8e4d0';                                // pale eye slit: direction stays readable in the dark
    ctx.fillRect(f > 0 ? x + p.w - 9 : x + 4, y + (p.crouch ? 5 : 9), 5, 3);

    if (p.weapon === 'crossbow') {
      ctx.fillStyle = '#2b2118';
      ctx.fillRect(f > 0 ? x + p.w : x - 14, y + (p.crouch ? 10 : 22), 14, 4);
    }
    if (p.swing > 0) {                                        // knife slash arc fades over its 8 frames
      var a = f > 0 ? 0 : Math.PI;
      ctx.strokeStyle = 'rgba(255,255,255,' + (p.swing / 8).toFixed(2) + ')';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x + p.w / 2, y + p.h / 2, 34, a - 0.9, a + 0.9);
      ctx.stroke();
    }
  }

  Z.Player = { create: create, update: update, draw: draw, hurt: hurt, slow: slow, hasItem: hasItem };
})(window.ZSYP = window.ZSYP || {});