// FILE: js/inventory.js
/*
 * Inventory (6 slots), journal and crafting. Pure data and logic; drawing lives in ui.js.
 * g.inv = { items[], ammo{bolts, poisoned}, weapons[], poisonBottle, notes[], used[], taken[] }
 * DECISION: slots hold items only. Weapons, bolts, the poison bottle and notes use no slot (notes go to the journal).
 */
(function (Z) {
  'use strict';

  var SLOTS = 6;

  /** The 15 journal entries, in story order. Ids match the room data. */
  var NOTES = {
    note_01: { title: 'Salon', text: 'Dzień 1 po wybuchu. Obudziłem się na podłodze w salonie, z dzwonieniem w uszach i smakiem metalu w ustach. Szyby wyleciały, a niebo za oknem ma kolor zgniłej pomarańczy. Gdzieś w tym bałaganie powinna leżeć latarka — bez światła w tym domu daleko nie zajdę. Na dole coś stuknęło, raz, jakby ktoś sprawdzał, czy ktoś tu jeszcze żyje.' },
    note_02: { title: 'Kuchnia', text: 'Dzień 2 po wybuchu. Zsyp w kuchni dawniej służył do wyrzucania śmieci, ale ojciec przerobił klapę i wzmocnił prowadnice. Mówił, że kiedyś posłuży do czegoś większego niż odpadki, a ja się z niego śmiałem. Dźwignia przy prawej ścianie jest martwa: bez prądu i bez klucza do mechanizmu nie ruszy. Pod kuchnią słychać wodę kapiącą w pustej piwnicy.' },
    note_03: { title: 'Przedpokój', text: 'Dzień 3 po wybuchu. Drzwi wejściowe ktoś zamknął od środka na łańcuch, a klucza nie ma nigdzie. Przez szparę wieje mrozem i słychać wiatr, który brzmi jak szept. Na framudze ojciec napisał kredą: „NIE WYCHODŹ”. Zapaliłem tu świecę — przy niej odzyskuję siły i mam wrażenie, że ktoś zapisuje to, co już przeżyłem.' },
    note_04: { title: 'Łazienka (parter)', text: 'Dzień 4 po wybuchu. Przez okienko łazienki słyszę z podwórka głos mamy — woła mnie po imieniu i prosi, żebym otworzył drzwi. Tylko że mama została na piętrze, w sypialni, widziałem ją przed wybuchem. Ten głos nie robi przerw na oddech między słowami. W szafce znalazłem apteczkę i schowałem ją na później.' },
    note_05: { title: 'Sypialnia', text: 'Dzień 6 po wybuchu. Zajrzałem do sypialni i zobaczyłem mamę stojącą tyłem do drzwi, w tej samej koszuli nocnej co zawsze. To nie jest już mama. Widzi tylko to, co ma przed sobą, więc można ją okrążyć, jeśli nie podejdzie zbyt blisko. Na szyi nadal wisi klucz do gabinetu ojca.' },
    note_06: { title: 'Pokój dziecięcy', text: 'Dzień 7 po wybuchu. Na ścianie w pokoju Stasia wisi rysunek: czarna plama z dwiema czerwonymi kropkami i podpis „TO CO JEST NA DOLE”. Narysował go tydzień przed wybuchem, a obok dorysował klatkę i strzałkę prowadzącą do kuchni. Jakby ktoś mu podpowiadał, jak to się skończy. Wziąłem jego pluszowego misia; nie wiem po co, ale nie mogę go tu zostawić.' },
    note_07: { title: 'Łazienka (piętro)', text: 'Dzień 9 po wybuchu. A może 10. Kreślę kreski na lustrze w łazience, ale rano jest ich zawsze o jedną więcej, niż pamiętam. Policzyłem dwa razy i za każdym razem wychodzi mi inna liczba. Przy świecy trzęsą mi się ręce trochę mniej.' },
    note_08: { title: 'Gabinet', text: 'Dzień 1 po wybuchu. Dziennik eksperymentu, wpis ostatni: obiekt 07 przerwał zabezpieczenia w bunkrze tuż przed uderzeniem. Nie reaguje na rany ani na ołów, reaguje tylko na ruch i hałas. Zamknąłem go w śluzie na najniższym poziomie, ale zawór wymaga korby, którą ukryłem na poddaszu. Jeśli to czytasz, nie otwieraj śluzy, dopóki nie będziesz miał planu.' },
    note_09: { title: 'Strych', text: 'Dzień 12 po wybuchu. Coś chodzi po suficie. Słyszę drobne, szybkie kroki, jakby ktoś stukał paznokciami, a potem cisza. Kiedy staję pod belką, cisza się kończy i ono spada. Klapa na poddasze jest zaklinowana, dopóki to coś tu mieszka.' },
    note_10: { title: 'Poddasze', text: 'Dzień 13 po wybuchu. Na poddaszu można tylko czołgać się na brzuchu; strop jest tak niski, że nic dużego by się tu nie zmieściło. Z ciemności przy kominie ktoś szepcze moje imię, ale kiedy świecę latarką, nikogo tam nie ma. Znalazłem korbę zaworu zawiniętą w szmatę, jakby ktoś chował ją przed samym sobą. To jedyne miejsce w domu, w którym czuję się bezpiecznie przed tym, co jest na dole.' },
    note_11: { title: 'Piwnica', text: 'Dzień 15 po wybuchu. Na ścianie piwnicy ojciec narysował węglem plan: bunkier, schody, przedpokój, kuchnia, klapa i klatka. Pod spodem dopisał dwa słowa: „klatka gotowa”. Klapa w kuchni otwiera się tylko na trzy sekundy, więc trzeba trafić w odpowiedni moment. Brakuje już tylko kogoś, kto poprowadzi to coś na górę.' },
    note_12: { title: 'Skład narzędzi', text: 'Dzień 16 po wybuchu. W składzie narzędzi stoi pusty słój z etykietą „Lycosa, okaz 3 — nie karmić”. Pająk, którego ojciec hodował w laboratorium, urósł do rozmiarów psa i pluje lepką siecią, która spowalnia każdy ruch. Strzela co kilka sekund, więc podejść trzeba tuż po strzale. Klucz do zsypu musi być w jego legowisku — wezmę go, gdy pająk przestanie się ruszać.' },
    note_13: { title: 'Kotłownia', text: 'Dzień 18 po wybuchu. Agregat w kotłowni nagle ruszył i w całym domu zapaliły się lampy. Prąd wrócił, ale to nie pomoże. Rury syczą parą co kilka sekund, więc trzeba przebiegać między wyrzutami. Znalazłem bezpiecznik, który pasuje do skrzynki w kuchni, i małą fiolkę z mętną cieczą.' },
    note_14: { title: 'Piwiczka', text: 'Dzień 19 po wybuchu. W piwiczce stoi butelka trucizny na szczury, a obok kartka z przepisem ojca. Na kuchennym stole trzeba wymieszać ją z fiolką z kotłowni i pokryć nią bełty do kuszy. Trucizna nie zabija od razu, ale pali jeszcze przez kilka sekund po trafieniu. Na to, co siedzi w bunkrze, nie zadziała nic — zapisał to wielkimi literami.' },
    note_15: { title: 'Bunkier', text: 'Dzień 20 po wybuchu. Na ścianie bunkra, czerwoną farbą, ręką ojca: TO NIE JEST CZŁOWIEK. NIE STRZELAJ. PROWADŹ. Mam go przeprowadzić przez piwnicę i przedpokój do kuchni, gdzie czeka klapa. Zima nuklearna dopiero się zaczyna.' }
  };

  function has(arr, v) { return arr.indexOf(v) >= 0; }
  function drop(arr, v) { var i = arr.indexOf(v); if (i >= 0) arr.splice(i, 1); return i >= 0; }

  /**
   * Fresh inventory. main.js calls this for every new game and every load, so it also clears the
   * per-session world state (boss, enemies, items, toast) that must not leak from the previous run.
   */
  function reset(g) {
    g.inv = { items: [], ammo: { bolts: 0, poisoned: 0 }, weapons: ['knife'], poisonBottle: false, notes: [], used: [], taken: [] };
    g.boss = null; g.enemies = []; g.items = []; g.webs = []; g.bolts = []; g.toast = null;
  }

  /** @returns {boolean} true if the item is in a slot right now */
  function holds(g, id) { return has(g.inv.items, id); }
  /** @returns {boolean} true if the item was consumed on a door, fuse box, lever or valve */
  function wasUsed(g, id) { return has(g.inv.used, id); }
  /** @returns {boolean} true if the pickup (id or uid) was ever collected, used up, or is a note/weapon we own */
  function owned(g, key) {
    var v = g.inv;
    return has(v.items, key) || has(v.used, key) || has(v.taken, key) || has(v.notes, key) || has(v.weapons, key);
  }

  /** @returns {boolean} false when all 6 slots are full */
  function add(g, id) {
    if (g.inv.items.length >= SLOTS) return false;
    g.inv.items.push(id);
    return true;
  }

  /** Spends a key item and remembers it in `used` (this is what unlocks doors for good). @returns {boolean} */
  function consume(g, id) {
    if (!drop(g.inv.items, id)) return false;
    if (!has(g.inv.used, id)) g.inv.used.push(id);
    return true;
  }

  /** Door/lever helper: true if the key was already used, or if we hold it now and it gets spent. */
  function tryUnlock(g, id) { return wasUsed(g, id) || consume(g, id); }

  /** @returns {boolean} true if the note is new (it is stored in the journal, never in a slot) */
  function addNote(g, id) {
    if (has(g.inv.notes, id)) return false;
    g.inv.notes.push(id);
    return true;
  }

  /** @returns {{id:string,title:string}[]} collected notes in story order, for the journal list */
  function noteList(g) {
    return Object.keys(NOTES).filter(function (id) { return has(g.inv.notes, id); })
      .map(function (id) { return { id: id, title: NOTES[id].title }; });
  }

  /**
   * Uses the item in slot `index` from the Tab menu (Enter or click).
   * DECISION: a consumable is always spent, even at full health, so a full pack can never soft-lock the game.
   * @returns {string|null} message to show
   */
  function use(g, index) {
    var id = g.inv.items[index], d = id && Z.Items.ITEMS[id], msg;
    if (!d) return null;
    if (!d.use) return d.name + ' — nie da się tego teraz użyć.';
    msg = d.use(g);
    g.inv.items.splice(index, 1);
    return msg;
  }

  /** Kitchen crafting station: poison bottle + vial coat up to 5 bolts. @returns {string} message */
  function craftPoison(g) {
    var v = g.inv, n, word;
    if (!v.poisonBottle) return 'Nie masz trucizny.';
    if (!has(v.items, 'vial')) return 'Brakuje fiolki z kotłowni.';
    if (v.ammo.bolts < 1) return 'Nie masz bełtów do zatrucia.';
    n = Math.min(5, v.ammo.bolts);
    v.ammo.poisoned = Math.min(v.ammo.bolts, v.ammo.poisoned + n);
    v.poisonBottle = false;
    drop(v.items, 'vial');
    word = n === 1 ? 'bełt' : (n < 5 ? 'bełty' : 'bełtów');
    return 'Pokryto trucizną: ' + n + ' ' + word + '. Każde trafienie truje przez 5 sekund.';
  }

  Z.Inventory = {
    SLOTS: SLOTS, NOTES: NOTES,
    reset: reset, has: holds, wasUsed: wasUsed, owned: owned,
    add: add, consume: consume, tryUnlock: tryUnlock,
    addNote: addNote, hasNote: function (g, id) { return has(g.inv.notes, id); }, noteList: noteList,
    use: use, craftPoison: craftPoison
  };
})(window.ZSYP = window.ZSYP || {});