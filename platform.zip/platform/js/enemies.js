// FILE: js/enemies.js
/*
 * Enemies. ENEMIES is the factory table: a new type is one new entry { create(x, y, opts), update(g, e), draw(ctx, g, e) }.
 * Every enemy has x, y, w, h, vx, vy, hp, dead, face. The boss is special: a single persistent object (g.boss)
 * that follows the player between rooms (see placeBoss) and can never be killed.
 */
(function (Z) {
  'use strict';

  var R = Z.Render;
  var FOLLOW_DELAY = 120;     // frames before the boss walks in behind the player after a room change
  var PROVOKED_PAUSE = 75;    // DECISION: the boss stands and growls for 1.25 s before it starts chasing

  function ov(a, b) { return R.overlap(a, b); }

  function solidAt(g, box) {
    var pl = g.room.platforms;
    for (var i = 0; i < pl.length; i++) if (ov(box, pl[i])) return true;
    return false;
  }

  /** Builds an enemy with the shared fields; `extra` adds or overrides type-specific ones. */
  function base(type, x, y, w, h, hp, extra) {
    var e = { type: type, x: x, y: y, w: w, h: h, vx: 0, vy: 0, hp: hp, dead: false, deadT: 0, face: 1, t: 0,
              dots: [], stun: 0, onGround: false, hitWall: 0, gravity: true };
    for (var k in extra) e[k] = extra[k];
    return e;
  }

  /**
   * Axis-separated movement against the room rectangles (same idea as the player).
   * e.footH lets the huge boss collide with its feet only, so low ceilings never wedge it in place.
   */
  function physics(g, e) {
    var pl = g.room.platforms, fh = e.footH || e.h, box = { x: e.x, y: e.y + e.h - fh, w: e.w, h: fh }, i, r;
    e.hitWall = 0;
    e.x += e.vx;
    box.x = e.x;
    for (i = 0; i < pl.length; i++) {
      r = pl[i];
      if (!ov(box, r)) continue;
      if (e.vx > 0) { e.x = r.x - e.w; e.hitWall = 1; } else if (e.vx < 0) { e.x = r.x + r.w; e.hitWall = -1; }
      box.x = e.x;
    }
    if (e.gravity) e.vy = Math.min(e.vy + 0.6, 16);
    e.y += e.vy;
    box.y = e.y + e.h - fh;
    e.onGround = false;
    for (i = 0; i < pl.length; i++) {
      r = pl[i];
      if (!ov(box, r)) continue;
      if (e.vy > 0) { e.y = r.y - e.h; e.onGround = true; } else if (e.vy < 0) e.y = r.y + r.h - (e.h - fh);
      e.vy = 0;
      box.y = e.y + e.h - fh;
    }
  }

  /** Underside of the nearest platform above the crawler (its ceiling); 0 when there is none. */
  function ceilingY(g, e) {
    var best = 0, pl = g.room.platforms, i, r, b;
    for (i = 0; i < pl.length; i++) {
      r = pl[i]; b = r.y + r.h;
      if (r.x < e.x + e.w && r.x + r.w > e.x && b <= e.y + e.h && b > best) best = b;
    }
    return best;
  }

  /* ------------------------------------------------------------ creation */

  function createZombie(x, y, o) {
    o = o || {};
    return base('zombie', x, y, 28, 52, 30, {
      homeX: x, aggro: 0, atk: 0, cool: 0, drop: o.drop || null,
      onDeath: function (g, e) { if (e.drop) Z.Items.spawnDrop(g, e.drop, e.x + e.w / 2, e.y + e.h); }
    });
  }

  function createCrawler(x, y) {
    return base('crawler', x, y, 20, 16, 40, {
      mode: 'ceiling', gravity: false, vision: 350, patrol: 1,
      onDeath: function (g) { g.flags.crawlerDead = true; }          // Rooms opens the poddasze hatch from this flag
    });
  }

  function createTarantula(x, y) {
    return base('tarantula', x, y, 40, 30, 80, {
      shootT: 60,
      onDeath: function (g, e) { g.flags.tarantulaDead = true; Z.Items.spawnDrop(g, 'key_chute', e.x + e.w / 2, e.y + e.h); }
    });
  }

  function createBoss(x, y) {
    return base('boss', x, y, 60, 90, 1, { state: 'idle', pt: 0, vision: 400, footH: 30, delay: 0, ax: 0, ay: 0, roomId: null });
  }

  /* ------------------------------------------------------------ damage */

  /**
   * Wakes the boss: idle -> provoked (growl, shake). Does nothing if it is already awake.
   * @param {object} g game
   * @param {object} [b] boss; defaults to g.boss
   */
  function provoke(g, b) {
    b = b || g.boss;
    if (!b || b.state !== 'idle') return;
    b.state = 'provoked'; b.pt = 0;
    g.flags.bossProvoked = true;
    Z.Audio.play('boss');
    R.shake(5, 40);
  }

  function kill(g, e) {
    e.dead = true; e.hp = 0; e.deadT = 0; e.vx = 0;
    R.spark(e.x + e.w / 2, e.y + e.h / 2, 16, '#8a1c1c');
    Z.Audio.play('zombie');
    if (e.onDeath) e.onDeath(g, e);
  }

  /**
   * Applies weapon damage. The boss takes none (spec: all damage = 0) and is only provoked.
   * @param {object} g game
   * @param {object} e enemy
   * @param {number} amount hit points to remove
   * @param {{poison:boolean}|null} src poisoned bolts add 10 damage over 5 s per hit
   */
  function damage(g, e, amount, src) {
    if (e.dead) return;
    if (e.type === 'boss') { provoke(g, e); return; }
    e.hp -= amount;
    e.stun = 8;
    if (e.type === 'zombie' && e.aggro === 0) e.aggro = 180;          // being stabbed wakes it up
    if (src && src.poison) e.dots.push(300);
    if (e.hp <= 0) kill(g, e);
  }

  function tickPoison(g, e) {
    if (!e.dots.length) return;
    e.hp -= e.dots.length * (10 / 300);                               // each poisoned hit = 10 dmg spread over 300 frames
    e.dots = e.dots.map(function (t) { return t - 1; }).filter(function (t) { return t > 0; });
    if (e.hp <= 0) kill(g, e);
  }

  /* ------------------------------------------------------------ AI */

  function touch(g, e, dmg) { if (ov(e, g.player)) Z.Player.hurt(g, dmg); }

  function updateZombie(g, e) {
    var p = g.player, dx = (p.x + p.w / 2) - (e.x + e.w / 2), dy = Math.abs((p.y + p.h) - (e.y + e.h));
    // Vision cone: 250 px in front, same height band only; anything within 60 px is sensed even from behind.
    var sees = dy < 70 && ((dx * e.face > 0 && Math.abs(dx) < 250) || Math.abs(dx) < 60);
    if (sees) { if (e.aggro === 0) Z.Audio.play('zombie'); e.aggro = 180; } else if (e.aggro > 0) e.aggro--;
    e.vx = 0;
    if (e.stun > 0) e.stun--;
    else if (e.atk > 0) {                                             // wind-up: the arm rises, then the blow lands
      if (--e.atk === 0) { if (Math.abs(dx) < 74 && dy < 70) Z.Player.hurt(g, 15); e.cool = 50; }
    } else {
      if (e.cool > 0) e.cool--;
      if (e.aggro > 0) {
        e.face = dx >= 0 ? 1 : -1;
        if (Math.abs(dx) < 60 && dy < 70 && e.cool === 0) e.atk = 20;
        else if (Math.abs(dx) > 30) e.vx = e.face * 1.2;
      } else {
        if (e.x > e.homeX + 120) e.face = -1; else if (e.x < e.homeX - 120) e.face = 1;   // patrol +-120 px
        e.vx = e.face * 0.6;                                          // DECISION: an unaware zombie shambles at half speed
      }
    }
    physics(g, e);
    if (e.hitWall && e.aggro === 0) e.face = -e.hitWall;
    touch(g, e, 15);
  }

  function updateCrawler(g, e) {
    var p = g.player, pcy = p.y + p.h / 2;
    var dx = (p.x + p.w / 2) - (e.x + e.w / 2), dy = pcy - (e.y + e.h / 2);
    var seen = Math.hypot(dx, dy) < e.vision;                         // 360 degrees, 350 px
    if (e.stun > 0) { e.stun--; return; }
    e.face = dx >= 0 ? 1 : -1;
    if (e.mode === 'ceiling') {                                       // stalks along the ceiling, then lets go above the prey
      e.gravity = false; e.vy = 0;
      e.y = ceilingY(g, e);
      e.vx = seen ? e.face * 2.8 : e.patrol;
      physics(g, e);
      if (e.hitWall && !seen) e.patrol = -e.patrol;
      if (seen && Math.abs(dx) < 14) { e.mode = 'drop'; e.gravity = true; }
    } else if (e.mode === 'drop') {
      e.vx = 0; e.gravity = true;
      physics(g, e);
      if (e.onGround) e.mode = 'ground';
    } else if (e.mode === 'ground') {                                 // hunts on the floor; a wall with prey above = climb it
      e.gravity = true;
      e.vx = seen && Math.abs(dx) > 4 ? e.face * 2.8 : 0;
      physics(g, e);
      if (e.hitWall && pcy < e.y - 30) e.mode = 'climb';
    } else {                                                          // climb: up the wall back to the ceiling
      e.vx = 0; e.vy = 0;
      e.y -= 2.8;
      var c = ceilingY(g, e);
      if (e.y <= c) { e.y = c; e.mode = 'ceiling'; }
    }
    touch(g, e, 20);
  }

  function shootWeb(g, e) {
    var p = g.player, sx = e.x + e.w / 2, sy = e.y + 8;
    var a = Math.atan2(p.y + p.h / 2 - sy, p.x + p.w / 2 - sx);
    g.webs.push({ x: sx, y: sy, vx: Math.cos(a) * 6, vy: Math.sin(a) * 6 });
    Z.Audio.play('knife', { vol: 0.6 });                              // a wet hiss
  }

  function updateTarantula(g, e) {
    var dx = (g.player.x + g.player.w / 2) - (e.x + e.w / 2);
    e.face = dx >= 0 ? 1 : -1;
    e.vx = Math.abs(dx) > 50 ? e.face * 1.0 : 0;                      // aggro from the moment the player enters the room
    physics(g, e);
    if (--e.shootT <= 0) { e.shootT = 120; shootWeb(g, e); }          // a web every 2 s
    touch(g, e, 10);
  }

  function updateWebs(g) {
    var box = { x: 0, y: 0, w: 12, h: 12 }, i, w;
    for (i = g.webs.length - 1; i >= 0; i--) {
      w = g.webs[i];
      w.x += w.vx; w.y += w.vy;
      box.x = w.x - 6; box.y = w.y - 6;
      if (w.x < -20 || w.x > g.W + 20 || w.y < -20 || w.y > g.H + 20 || solidAt(g, box)) { g.webs.splice(i, 1); continue; }
      if (ov(box, g.player)) { Z.Player.hurt(g, 8); Z.Player.slow(g, 60); g.webs.splice(i, 1); }
    }
  }

  function updateBoss(g, b) {
    var p = g.player, dx = (p.x + p.w / 2) - (b.x + b.w / 2), dy = (p.y + p.h / 2) - (b.y + b.h / 2);
    if (b.state === 'falling') { sinkBoss(g, b); return; }
    if (b.delay > 0) {                                                // still "behind the door" after a room change
      if (--b.delay === 0) {
        if (Math.abs((p.x + p.w / 2) - (b.ax + b.w / 2)) < 160) { b.delay = 1; return; }   // never pop out on top of the player
        b.x = b.ax; b.y = b.ay;
        nudgeFree(g, b);
        Z.Audio.play('boss');
        R.shake(5, 20);
      }
      return;
    }
    b.face = dx >= 0 ? 1 : -1;
    if (b.state === 'idle') { b.vx = 0; if (Math.hypot(dx, dy) < b.vision) provoke(g, b); }   // wakes at 400 px
    else if (b.state === 'provoked') { b.vx = 0; if (++b.pt >= PROVOKED_PAUSE) b.state = 'chase'; }
    else b.vx = b.face * 2.6;
    physics(g, b);
    if (ov(b, p)) Z.Player.hurt(g, 100);                              // contact = instant death
  }

  /** The trapdoor sequence: the boss sinks through the floor, then Rooms runs the cage cutscene. */
  function sinkBoss(g, b) {
    b.vy = Math.min(b.vy + 0.7, 16);
    b.y += b.vy;
    if (++b.fallT % 6 === 0) R.dust(b.x + b.w / 2, b.y, 3);
    if (b.y > g.H + 20) {
      g.enemies.splice(g.enemies.indexOf(b), 1);
      g.boss = null;
      g.flags.bossTrapped = true;
      if (Z.Rooms.onBossFallen) Z.Rooms.onBossFallen(g);
    }
  }

  /**
   * Starts the boss falling. Rooms calls this when the lever is pulled while the boss overlaps the trapdoor zone.
   * @returns {boolean} false if there is no boss here to drop
   */
  function dropBoss(g) {
    var b = g.boss;
    if (!b || b.state === 'falling' || b.delay > 0 || g.enemies.indexOf(b) < 0) return false;
    b.state = 'falling'; b.vx = 0; b.vy = 1; b.fallT = 0; b.gravity = false;
    Z.Audio.play('trapdoor');
    R.dust(b.x + b.w / 2, b.y + b.h, 30);
    return true;
  }

  /* ------------------------------------------------------------ drawing */

  function drawZombie(ctx, g, e) {
    var x = e.x, y = e.y, f = e.face, w = e.w, i, reach = e.atk > 0 ? 26 : 12;
    ctx.save();
    if (e.dead) ctx.globalAlpha = Math.max(0, 1 - e.deadT / 90);
    ctx.fillStyle = e.stun > 0 ? '#7a9a70' : '#3f5a3a';
    ctx.beginPath();                                                  // body with a tattered, jagged top edge
    ctx.moveTo(x, y + e.h);
    ctx.lineTo(x, y + 6);
    for (i = 1; i <= 7; i++) ctx.lineTo(x + i * w / 7, y + (i % 2 ? 0 : 7) + (i === 3 ? 3 : 0));
    ctx.lineTo(x + w, y + e.h);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#6f8f68'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#050805';                                        // hollow eye sockets and mouth
    ctx.fillRect(x + 6, y + 12, 6, 7); ctx.fillRect(x + 16, y + 12, 6, 7); ctx.fillRect(x + 10, y + 26, 8, 4);
    ctx.fillStyle = '#34502f';                                        // arm stretches out during the wind-up
    ctx.fillRect(f > 0 ? x + w - 4 : x + 4 - reach, y + (e.atk > 0 ? 16 : 22), reach, 6);
    ctx.restore();
  }

  function drawCrawler(ctx, g, e) {
    var x = e.x, y = e.y, cx = x + e.w / 2, cy = y + e.h / 2, up = e.mode === 'ceiling' ? -1 : 1, i, s, sw;
    ctx.save();
    if (e.dead) ctx.globalAlpha = Math.max(0, 1 - e.deadT / 90);
    ctx.strokeStyle = '#1d1d1d'; ctx.lineWidth = 1;                   // hair-thin legs, 3 per side, reaching for the surface
    for (s = -1; s <= 1; s += 2) for (i = 0; i < 3; i++) {
      sw = e.dead ? 0 : Math.sin(e.t * 0.5 + i * 2) * 3;
      ctx.beginPath();
      ctx.moveTo(cx + s * 5, cy + (i - 1) * 4);
      ctx.lineTo(cx + s * (14 + i * 2), cy + (i - 1) * 6 + up * (6 + sw));
      ctx.stroke();
    }
    ctx.fillStyle = '#120f14'; ctx.fillRect(x, y, e.w, e.h);
    ctx.strokeStyle = '#3a3340'; ctx.strokeRect(x + 0.5, y + 0.5, e.w - 1, e.h - 1);
    ctx.fillStyle = '#d22'; ctx.fillRect(x + (e.face > 0 ? 13 : 4), y + 4, 3, 2);
    ctx.restore();
  }

  function drawTarantula(ctx, g, e) {
    var x = e.x, y = e.y, cx = x + e.w / 2, ex = cx + e.face * 8, s, i, sw;
    ctx.save();
    if (e.dead) ctx.globalAlpha = Math.max(0, 1 - e.deadT / 90);
    ctx.strokeStyle = '#0b0b0b'; ctx.lineWidth = 3;                   // 8 bezier legs, 4 per side, arched over the body
    for (s = -1; s <= 1; s += 2) for (i = 0; i < 4; i++) {
      sw = e.dead ? 0 : Math.sin(e.t * 0.15 + i * 1.7) * 4;
      ctx.beginPath();
      ctx.moveTo(cx + s * 12, y + 10 + i * 3);
      ctx.bezierCurveTo(cx + s * 26, y - 16 + i * 5 + sw, cx + s * (36 + i * 3), y - 8 + sw, cx + s * (34 + i * 5), y + e.h);
      ctx.stroke();
    }
    ctx.fillStyle = '#050505'; ctx.fillRect(x, y, e.w, e.h);
    ctx.strokeStyle = '#2a2a2a'; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, e.w - 1, e.h - 1);
    ctx.shadowColor = '#f22'; ctx.shadowBlur = 8; ctx.fillStyle = '#ff2a2a';   // cluster of red eyes
    ctx.fillRect(ex - 5, y + 6, 3, 3); ctx.fillRect(ex + 1, y + 6, 3, 3);
    ctx.fillRect(ex - 3, y + 11, 2, 2); ctx.fillRect(ex + 2, y + 11, 2, 2);
    ctx.restore();
  }

  function drawBoss(ctx, g, e) {
    if (e.delay > 0) return;
    var x = e.x, y = e.y, cx = x + e.w / 2, by = y + e.h, awake = e.state !== 'idle';
    var k = 1.02 + 0.02 * Math.sin(e.t * 0.05);                       // breathing: scale 1.0 <-> 1.04 from the feet up
    var flash = e.state === 'provoked' && ((e.t >> 2) & 1);
    ctx.save();
    ctx.translate(cx, by); ctx.scale(k, k); ctx.translate(-cx, -by);
    ctx.fillStyle = '#08080b';
    ctx.beginPath();
    ctx.moveTo(x, by);
    [[4, 44], [10, 16], [22, 4], [38, 4], [50, 16], [56, 44], [60, 90]].forEach(function (p) { ctx.lineTo(x + p[0], y + p[1]); });
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#26262e'; ctx.lineWidth = 2; ctx.stroke();
    ctx.shadowColor = '#f22'; ctx.shadowBlur = awake ? 14 : 0;       // red glints: dim while idle, bright once provoked
    ctx.fillStyle = awake ? (flash ? '#ffffff' : '#ff2a2a') : '#5a1212';
    ctx.fillRect(x + 18, y + 20, 7, 4); ctx.fillRect(x + 35, y + 20, 7, 4);
    ctx.restore();
  }

  function drawWebs(ctx, g) {
    ctx.strokeStyle = 'rgba(235,235,235,0.85)'; ctx.lineWidth = 1;
    g.webs.forEach(function (w) {
      ctx.beginPath();
      ctx.arc(w.x, w.y, 6, 0, Math.PI * 2);
      ctx.moveTo(w.x - 6, w.y); ctx.lineTo(w.x + 6, w.y);
      ctx.moveTo(w.x, w.y - 6); ctx.lineTo(w.x, w.y + 6);
      ctx.stroke();
    });
  }

  /* ------------------------------------------------------------ table, spawning, boss placement */

  var ENEMIES = {
    zombie:    { create: createZombie,    update: updateZombie,    draw: drawZombie },
    crawler:   { create: createCrawler,   update: updateCrawler,   draw: drawCrawler },
    tarantula: { create: createTarantula, update: updateTarantula, draw: drawTarantula },
    boss:      { create: createBoss,      update: updateBoss,      draw: drawBoss }
  };

  function canSpawn(g, d) {
    if (d.type === 'crawler') return !g.flags.crawlerDead;
    if (d.type === 'tarantula') return !g.flags.tarantulaDead;
    // DECISION: a zombie that guards a key walks again until that key has been taken, so the key can never be lost
    if (d.type === 'zombie' && d.drop) return !Z.Inventory.owned(g, d.drop);
    return true;
  }

  /** Moves the boss sideways to the nearest spot where its feet are not inside a wall. */
  function nudgeFree(g, b) {
    var box = { x: b.x, y: b.y + b.h - b.footH, w: b.w, h: b.footH }, k, s, x;
    for (k = 0; k < 40; k++) {
      for (s = -1; s <= 1; s += 2) {
        x = R.clamp(b.x + s * k * 10, 0, g.W - b.w);
        box.x = x;
        if (!solidAt(g, box)) { b.x = x; return; }
      }
    }
  }

  /** The boss "follows through the door": it is parked off-screen, then walks in at the entrance after a delay. */
  function arrive(g, b, room) {
    var e = g.entrance;
    b.roomId = room.id;
    if (b.state === 'provoked') b.state = 'chase';
    b.ax = R.clamp(e.x + 12 - b.w / 2, 0, g.W - b.w);
    b.ay = e.y + 48 - b.h;
    b.x = -1000; b.y = -1000;                                         // off-screen = cannot be hit or seen while it waits
    b.vx = 0; b.vy = 0; b.gravity = true;
    b.delay = FOLLOW_DELAY;
    g.enemies.push(b);
  }

  function placeBoss(g, room) {
    var b = g.boss;
    if (g.flags.bossTrapped) { g.boss = null; return; }
    if (!b && room.bossHome) {                                        // first visit to the bunker: it wakes in front of the player
      b = g.boss = createBoss(room.bossHome.x, room.bossHome.y);
      b.roomId = room.id;
      g.enemies.push(b);
      provoke(g, b);
      return;
    }
    if (!b && g.flags.bossProvoked) { b = g.boss = createBoss(0, 0); b.state = 'chase'; }   // loaded a save made mid-hunt
    if (!b || b.state === 'falling' || room.noBoss) return;           // noBoss (poddasze): too big to follow, it stays behind
    arrive(g, b, room);
  }

  /**
   * Rebuilds g.enemies for a room. Rooms.enter calls this after setting g.room, g.roomId and g.entrance.
   * Room data: enemies: [{type, x, y, drop?}], bossHome: {x, y} (bunkier), noBoss: true (poddasze).
   */
  function populate(g, room) {
    g.enemies = [];
    g.webs = [];
    (room.enemies || []).forEach(function (d) {
      if (!ENEMIES[d.type]) { console.warn('ZSYP: unknown enemy type "' + d.type + '" in ' + room.id); return; }
      if (canSpawn(g, d)) g.enemies.push(ENEMIES[d.type].create(d.x, d.y, d));
    });
    placeBoss(g, room);
  }

  /** One simulation step for every enemy and web in the current room. */
  function update(g) {
    var list = g.enemies, i, e;
    for (i = list.length - 1; i >= 0; i--) {
      e = list[i];
      e.t++;
      if (e.dead) {                                                   // corpses fall, fade for 1.5 s, then vanish
        e.gravity = true; e.vx = 0;
        physics(g, e);
        if (++e.deadT > 90) list.splice(i, 1);
        continue;
      }
      tickPoison(g, e);
      if (!e.dead) ENEMIES[e.type].update(g, e);
    }
    updateWebs(g);
  }

  function draw(ctx, g) {
    g.enemies.forEach(function (e) { ENEMIES[e.type].draw(ctx, g, e); });
    drawWebs(ctx, g);
  }

  Z.Enemies = {
    ENEMIES: ENEMIES,
    /** @returns {object} a new enemy of a registered type (used by Rooms and by sequels). */
    create: function (type, x, y, o) { return ENEMIES[type].create(x, y, o || {}); },
    populate: populate, update: update, draw: draw, damage: damage, provoke: provoke, dropBoss: dropBoss
  };
})(window.ZSYP = window.ZSYP || {});