// FILE: js/items.js
/*
 * Pickups lying in rooms. ITEMS is the definition table: a new item is one new entry
 * { name, color, prompt, pickup(g, it) -> true when it leaves the room, use(g) -> message (optional, from the Tab menu) }.
 * Rooms list them as { id, uid?, x, y, when?(g) }; `uid` tells two pickups with the same id apart (battery_1, battery_2).
 */
(function (Z) {
  'use strict';

  var REACH = 50;                          // px between centres within which [E] works
  var PROMPT = '[E] Podnieś';

  /** Shows a message for about 3 s; ui.js draws g.toast = {text, t}. */
  function say(g, text) { g.toast = { text: text, t: 200 }; }

  /** Default pickup: one of the 6 inventory slots. A full pack refuses, and never blocks progress (see Inventory.use). */
  function slotPickup(g, it) {
    if (!Z.Inventory.add(g, it.id)) { say(g, 'Ekwipunek pełny. Zużyj coś w menu (Tab) albo wykorzystaj klucz.'); return false; }
    Z.Audio.play('pickup');
    say(g, 'Podniesiono: ' + ITEMS[it.id].name + '.');
    return true;
  }

  function def(name, color, extra) {
    var d = { name: name, color: color, prompt: PROMPT, pickup: slotPickup };
    for (var k in extra) d[k] = extra[k];
    return d;
  }

  function crossbowPickup(g) {
    if (g.inv.weapons.indexOf('crossbow') < 0) g.inv.weapons.push('crossbow');
    Z.Audio.play('pickup');
    say(g, 'Znaleziono kuszę. [Q] zmienia broń.');
    return true;
  }

  function boltsPickup(g) {
    var a = g.inv.ammo;
    if (a.bolts >= 10) { say(g, 'Kołczan jest pełny.'); return false; }   // 10 bolts max: leave the rest for later
    a.bolts = Math.min(10, a.bolts + 5);
    Z.Audio.play('pickup');
    say(g, 'Bełty: ' + a.bolts + '/10.');
    return true;
  }

  function poisonPickup(g) {
    g.inv.poisonBottle = true;               // DECISION: the bottle rides in the quiver, so it uses no slot
    Z.Audio.play('pickup');
    say(g, 'Trucizna na szczury. Połącz ją z fiolką na kuchennym stole.');
    return true;
  }

  function notePickup(g, it) {
    Z.Inventory.addNote(g, it.id);
    g.openNote(it.id);                       // opens the viewer and plays the pickup sound
    return true;
  }

    /** Candles are never used up: E heals 20 HP, then saves (so the save holds the healed value), any number of times. */
  function candlePickup(g) {
    var p = g.player, ok;
    p.hp = Math.min(100, p.hp + 20);
    ok = Z.Save.write(g);
    Z.Audio.play('candle');
    say(g, ok ? 'Gra zapisana. +20 HP.' : 'Zapis tylko na czas tej sesji. +20 HP.');
    return false;
  }

  var ITEMS = {
    flashlight:   def('Latarka', '#e8d48a'),
    battery:      def('Bateria', '#7ad47a', { use: function (g) { g.player.battery = Math.min(100, g.player.battery + 40); return 'Bateria latarki +40%.'; } }),
    first_aid:    def('Apteczka', '#d84a4a', { use: function (g) { g.player.hp = Math.min(100, g.player.hp + 40); return 'Zdrowie +40.'; } }),
    crowbar:      def('Łom', '#9aa4b0'),
    gabinet_key:  def('Klucz do gabinetu', '#d9b64a'),
    key_chute:    def('Klucz do zsypu', '#d98a3a'),
    valve_handle: def('Korba zaworu', '#b0603a'),
    fuse:         def('Bezpiecznik', '#e0d04a'),
    vial:         def('Fiolka', '#6ad0d8'),
    teddy_bear:   def('Pluszowy miś', '#b98a5a'),
    crossbow:     def('Kusza', '#8a6a40', { pickup: crossbowPickup }),
    bolts:        def('Bełty (5)', '#c9b79c', { pickup: boltsPickup }),
    trucizna:     def('Trucizna na szczury', '#9ad23a', { pickup: poisonPickup }),
    candle:       def('Świeca', '#ffcf70', { prompt: '[E] Zapisz grę', persistent: true, pickup: candlePickup })
  };
  for (var n = 1; n <= 15; n++) {
    ITEMS['note_' + (n < 10 ? '0' : '') + n] = def('Notatka', '#d8cfa8', { note: true, prompt: '[E] Przeczytaj', pickup: notePickup });
  }

  function make(id, uid, x, y) {
    return { id: id, uid: uid, x: x, y: y, w: 16, h: 16, t: Math.floor(Math.random() * 60), drop: false, vy: 0 };
  }

  /**
   * Fills g.items from room.items, skipping anything already collected (so nothing respawns).
   * Rooms.enter calls this right after Enemies.populate.
   */
  function spawnFor(g, room) {
    g.items = [];
    (room.items || []).forEach(function (d) {
      var uid = d.uid || d.id;
      if (!ITEMS[d.id]) { console.warn('ZSYP: unknown item "' + d.id + '" in ' + room.id); return; }
      if (!ITEMS[d.id].persistent && Z.Inventory.owned(g, uid)) return;
      if (d.when && !d.when(g)) return;
      g.items.push(make(d.id, uid, d.x, d.y));
    });
  }

  /**
   * Drops an item that falls to the floor (zombie key, tarantula key).
   * @param {number} x centre x   @param {number} y floor y
   */
  function spawnDrop(g, id, x, y) {
    if (Z.Inventory.owned(g, id)) return;
    for (var i = 0; i < g.items.length; i++) if (g.items[i].uid === id) return;
    var it = make(id, id, x - 8, y - 16);
    it.drop = true; it.vy = -3;
    g.items.push(it);
  }

  function take(g, it) {
    if (!ITEMS[it.id].pickup(g, it)) return;
    g.items.splice(g.items.indexOf(it), 1);
    if (g.inv.taken.indexOf(it.uid) < 0) g.inv.taken.push(it.uid);
  }

  /** One step: toast timer, dropped items falling, and the nearest-item [E] prompt. */
  function update(g) {
    var p = g.player, best = null, bd = REACH, i, it, d, pl = g.room.platforms, j;
    if (g.toast && --g.toast.t <= 0) g.toast = null;
    for (i = 0; i < g.items.length; i++) {
      it = g.items[i];
      it.t++;
      if (it.drop) {
        it.vy += 0.6; it.y += it.vy;
        for (j = 0; j < pl.length; j++) {
          if (it.vy > 0 && Z.Render.overlap(it, pl[j])) { it.y = pl[j].y - it.h; it.vy = 0; it.drop = false; }
        }
      }
      d = Math.hypot(it.x + 8 - (p.x + p.w / 2), it.y + 8 - (p.y + p.h / 2));
      if (d < bd) { bd = d; best = it; }
    }
    if (!best) return;
    g.prompt = ITEMS[best.id].prompt;         // Rooms must skip its own props while g.prompt is set
    if (Z.Input.pressed('interact')) take(g, best);
  }

  function drawCandle(ctx, it) {
    ctx.fillStyle = '#e8dcc0';
    ctx.fillRect(it.x + 4, it.y + 2, 8, 14);
    ctx.fillStyle = '#ffb347';
    ctx.beginPath();
    ctx.ellipse(it.x + 8, it.y - 2, 3, 5 + Math.sin(it.t * 0.3) * 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  /** 16x16 coloured squares with a 1 px border and a pulsing glow (shadowBlur up to 8). */
  function draw(ctx, g) {
    for (var i = 0; i < g.items.length; i++) {
      var it = g.items[i], d = ITEMS[it.id], pulse = 0.5 + 0.5 * Math.sin(it.t * 0.08);
      ctx.save();
      ctx.shadowColor = d.color;
      ctx.shadowBlur = 4 + 4 * pulse;
      if (it.id === 'candle') drawCandle(ctx, it);
      else {
        ctx.fillStyle = d.color;
        ctx.fillRect(it.x, it.y, 16, 16);
        ctx.shadowBlur = 0;
        ctx.strokeStyle = 'rgba(0,0,0,0.75)'; ctx.lineWidth = 1;
        ctx.strokeRect(it.x + 0.5, it.y + 0.5, 15, 15);
        if (d.note) {                                                // ruled lines make a note read as paper
          ctx.fillStyle = 'rgba(60,50,30,0.7)';
          ctx.fillRect(it.x + 3, it.y + 4, 10, 1); ctx.fillRect(it.x + 3, it.y + 8, 10, 1); ctx.fillRect(it.x + 3, it.y + 12, 6, 1);
        }
      }
      ctx.restore();
    }
  }

  Z.Items = { ITEMS: ITEMS, update: update, draw: draw, spawnFor: spawnFor, spawnDrop: spawnDrop, say: say };
})(window.ZSYP = window.ZSYP || {});