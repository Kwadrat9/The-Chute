// FILE: js/audio.js
/*
 * Procedural audio (Web Audio API). Every sound is oscillators + filtered noise, so no audio files exist.
 * Envelope rule for all sounds: 10 ms attack, then an exponential decay whose length is per sound.
 */
(function (Z) {
  'use strict';

  var MASTER = 0.6;                      // spec: master gain 0.6
  var ac = null, master = null, noiseBuf = null, drone = null;
  var muted = false, ambientWanted = false;

  /** Waveshaper curve for the boss growl (the classic distortion formula). */
  function distCurve(k) {
    var n = 256, c = new Float32Array(n), i, x;
    for (i = 0; i < n; i++) {
      x = i * 2 / n - 1;
      c[i] = (3 + k) * x * 20 * (Math.PI / 180) / (Math.PI + k * Math.abs(x));
    }
    return c;
  }

  /** Envelope gain wired to the master bus: 10 ms attack to `peak`, exponential decay over `dur` seconds. */
  function envGain(t, peak, dur) {
    var gn = ac.createGain();
    gn.gain.setValueAtTime(0.0001, t);
    gn.gain.linearRampToValueAtTime(peak, t + 0.01);
    gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    gn.connect(master);
    return gn;
  }

  /** Oscillator sweeping f0 -> f1 over `dur` seconds. Returns the envelope gain so callers can modulate it. */
  function tone(type, f0, f1, dur, peak, t) {
    var o = ac.createOscillator(), out = envGain(t, peak, dur);
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    o.connect(out);
    o.start(t);
    o.stop(t + dur + 0.05);
    return out;
  }

  /** Filtered noise burst; filter type and frequency give each effect its colour. */
  function noise(filter, freq, q, dur, peak, t) {
    var s = ac.createBufferSource(), f = ac.createBiquadFilter(), out = envGain(t, peak, dur);
    s.buffer = noiseBuf;
    f.type = filter; f.frequency.value = freq; f.Q.value = q;
    s.connect(f);
    f.connect(out);
    s.start(t, Math.random());           // random offset into the shared buffer so repeats don't sound identical
    s.stop(t + dur + 0.05);
  }

  /** Each sound: function(volumeMultiplier, startTime). Names are the public API for Audio.play. */
  var SOUNDS = {
    footstep: function (v, t) { noise('lowpass', 420, 0.7, 0.06, 0.5 * v, t); },
    jump:     function (v, t) { tone('sine', 220, 440, 0.12, 0.25 * v, t); },
    knife:    function (v, t) { noise('bandpass', 1800, 1.2, 0.1, 0.35 * v, t); },
    crossbow: function (v, t) { tone('square', 90, 90, 0.18, 0.22 * v, t); noise('lowpass', 1500, 0.7, 0.18, 0.25 * v, t); },
    hit:      function (v, t) { noise('lowpass', 900, 0.5, 0.08, 0.45 * v, t); },   // low-passed white noise reads as "pink-ish"
    click:    function (v, t) { noise('highpass', 3000, 0.7, 0.03, 0.2 * v, t); }, // DECISION: dry click for empty crossbow / flashlight / weapon swap
    pickup:   function (v, t) { tone('triangle', 660, 660, 0.08, 0.3 * v, t); },
    // DECISION: "500→800" read as two chime tones (500 Hz, then 800 Hz), the second ringing longer
    candle:   function (v, t) { tone('sine', 500, 500, 0.5, 0.25 * v, t); tone('sine', 800, 800, 0.8, 0.22 * v, t + 0.22); },
    trapdoor: function (v, t) { tone('sine', 60, 60, 0.4, 0.5 * v, t); noise('lowpass', 500, 0.7, 0.4, 0.35 * v, t); },
    zombie: function (v, t) {
      var out = tone('sawtooth', 70, 70, 0.9, 0.3 * v, t);
      var lfo = ac.createOscillator(), depth = ac.createGain();   // slow wobble on the volume = a wet, rattling growl
      lfo.frequency.value = 5; depth.gain.value = 0.08;
      lfo.connect(depth); depth.connect(out.gain);
      lfo.start(t); lfo.stop(t + 0.95);
    },
    boss: function (v, t) {
      var o = ac.createOscillator(), sh = ac.createWaveShaper(), out = envGain(t, 0.5 * v, 1.5);
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(40, t);
      o.frequency.linearRampToValueAtTime(34, t + 1.5);           // the growl sags as it ends
      sh.curve = distCurve(60);
      o.connect(sh); sh.connect(out);
      o.start(t); o.stop(t + 1.55);
    },
    win: function (v, t) {                                        // A minor, descending, about 2 s
      [880, 659.25, 523.25, 440, 329.63, 261.63].forEach(function (f, i) {
        tone('triangle', f, f, 0.55, 0.28 * v, t + i * 0.28);
      });
    }
  };

  function startDrone() {
    if (!ac || drone) return;
    var o = ac.createOscillator(), gn = ac.createGain();
    o.type = 'sine'; o.frequency.value = 40;
    gn.gain.value = 0;
    gn.gain.setTargetAtTime(0.02, ac.currentTime, 0.5);           // fades in so it creeps up on the player
    o.connect(gn); gn.connect(master);
    o.start();
    drone = { o: o, g: gn };
  }

  function stopDrone() {
    if (!drone) return;
    var d = drone;
    drone = null;
    d.g.gain.setTargetAtTime(0, ac.currentTime, 0.3);
    d.o.stop(ac.currentTime + 1.5);
  }

  Z.Audio = {
    /** Creates (or resumes) the AudioContext. Must run inside a user gesture; safe to call repeatedly. */
    init: function () {
      if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
      var AC = window.AudioContext || window.webkitAudioContext, len, d, i;
      if (!AC) return;                                            // no Web Audio: the game stays silent but playable
      ac = new AC();
      master = ac.createGain();
      master.gain.value = muted ? 0 : MASTER;
      master.connect(ac.destination);
      len = ac.sampleRate * 2;                                    // 2 s of white noise, reused by every noise effect
      noiseBuf = ac.createBuffer(1, len, ac.sampleRate);
      d = noiseBuf.getChannelData(0);
      for (i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      if (ambientWanted) startDrone();
    },
    /**
     * Plays a named sound: footstep, jump, knife, crossbow, hit, click, pickup, candle, trapdoor, zombie, boss, win.
     * @param {string} name sound name
     * @param {{vol:number}} [opts] vol multiplier (e.g. 0.35 for crouched footsteps)
     */
    play: function (name, opts) {
      if (!ac || muted || !SOUNDS[name]) return;
      try { SOUNDS[name]((opts && opts.vol) || 1, ac.currentTime); } catch (e) { /* audio must never crash the game */ }
    },
    /** @param {boolean} m true silences the master bus (pause menu). */
    setMuted: function (m) {
      muted = !!m;
      if (master) master.gain.setTargetAtTime(muted ? 0 : MASTER, ac.currentTime, 0.02);
    },
    /** @param {boolean} on starts/stops the 40 Hz drone used in piwnica, bunkier and poddasze. */
    setAmbient: function (on) {
      ambientWanted = !!on;
      if (on) startDrone(); else stopDrone();
    }
  };
})(window.ZSYP = window.ZSYP || {});