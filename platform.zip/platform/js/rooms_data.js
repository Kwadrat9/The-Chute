// FILE: js/rooms_data.js
/*
 * The 17 room definitions: pure data (geometry, exits, props, items, enemies). All behaviour lives in rooms.js,
 * which must load BEFORE this file (index.html order: ... rooms.js, rooms_data.js, save.js, main.js).
 *
 * ROOM SHAPE (1280x720 room; floor top y = 650, ceiling underside y = 40):
 *   name, floor        Polish labels for the HUD (top-right)
 *   bgColor, fg        background colour and platform fill (platforms get a lighter 2 px stroke)
 *   dark, ambient      darkness vignette / 40 Hz drone;   crouchOnly: forced crouch, no jumping
 *   noBoss             the boss cannot follow into this room;   bossHome {x, y}: where the boss first wakes
 *   fallFade           fade frames per half after falling out of the room (default 18 = 300 ms)
 *   platforms          solid {x, y, w, h};   deco: [x, y, w, h, colour] background shapes (not solid)
 *   spawns             STANDING top-left positions. `default` is required; the others are named entrances that
 *                      exits select with `at`. g.entrance = the spawn actually used (a saved {x, y} uses `default`):
 *                      it is where the boss re-enters and where a fall respawns you.
 *   exits              {kind:'edge', side:'left'|'right', y0, y1, to, at, need}: walk into that screen edge while
 *                      your vertical centre is inside [y0, y1]
 *   props              all use [E]:
 *                        door | stairs | ladder | hatch   {x, y, w, h, label, to, at, need, dir, reach}
 *                          (reach = extra px below the rect that still count as "at the hatch")
 *                        trapdoor {open, cooldown} | lever | fusebox | crafting | valve {item, hold} | chained
 *   need               {item}: key item, spent on first use (Inventory.tryUnlock)
 *                      {flag}: g.flags[flag] must be true      {used}: Inventory.wasUsed(...) must be true
 *                      msg = toast when refused, ok = toast when it opens
 *   items              {id, uid?, x, y}: uid tells two pickups with one id apart (battery_1, battery_2)
 *   enemies            {type, x, y, drop?}: x, y = top-left of the enemy box
 *   hazards            {kind:'steam', x, y, w, h, on, off, at}: 10 dmg while on; `at` = phase offset in frames
 *   cage, chute        piwnica_zsyp only: where the trapped boss slides in and the cage slams
 * rooms.js crouches the player on arrival when the standing box would overlap a platform (bunker tunnel,
 * crouch-only rooms). Item y: floor pickups 634; on a plank whose top is T: T - 16.
 * Placement rules: a jump rises 110 px at most (steps stay <= 100) and clears ~120 px sideways at walking pace.
 */
(function (Z) {
  'use strict';

  var R = Z.Rooms;
  if (!R || !R.registerRoom) { console.error('ZSYP: rooms_data.js must load after rooms.js'); return; }

  var FLOOR = [0, 650, 1280, 70], CEIL = [0, 0, 1280, 40], Y = 602;   // Y = standing top-left y on the floor

  /** [x, y, w, h] rows -> platform objects. */
  function rects(rows) { return rows.map(function (r) { return { x: r[0], y: r[1], w: r[2], h: r[3] }; }); }
  /** Standing spawn on the floor at x. */
  function sp(x) { return { x: x, y: Y }; }
  /** Walk-through exit on the left or right screen edge, usable at floor height. */
  function edge(side, to, at, need) {
    return { kind: 'edge', side: side, y0: 540, y1: 660, to: to, at: at || 'default', need: need || null };
  }
  /** Shared builder for door / stairs / ladder / hatch props. */
  function pass(kind, x, y, w, h, label, to, at, need, dir, reach) {
    return { kind: kind, x: x, y: y, w: w, h: h, label: label, to: to, at: at || 'default', need: need || null, dir: dir, reach: reach || 0 };
  }
  function door(x, label, to, at, need) { return pass('door', x, 520, 70, 130, label, to, at, need); }
  function stairs(x, label, to, at, need, dir, w) { return pass('stairs', x, 470, w || 130, 180, label, to, at, need, dir); }
  function ladder(x, label, to, at, dir) { return pass('ladder', x, 200, 50, 450, label, to, at, null, dir); }

  /* ============================================================ FLOOR 0: PARTER */

  R.registerRoom('salon', {
    name: 'Salon', floor: 'Parter', bgColor: '#1d1713', fg: '#3b2f27',
    platforms: rects([FLOOR, CEIL, [700, 575, 170, 16]]),
    deco: [[120, 150, 150, 200, '#4a3320'], [980, 150, 140, 200, '#4a3320'], [440, 530, 230, 120, '#2a2019']],   // two blown-out windows, a sofa
    spawns: { default: sp(640), fromKuchnia: sp(1220), fromStairs: sp(210) },
    exits: [edge('right', 'kuchnia', 'fromSalon')],
    props: [stairs(60, 'Schody na piętro', 'sypialnia', 'fromStairs', null, 'up')],   // DECISION: pietro_hall is not one of the 17 rooms; the stairs lead straight to sypialnia
    items: [{ id: 'note_01', x: 380, y: 634 }, { id: 'flashlight', x: 770, y: 559 }]
  });

  R.registerRoom('kuchnia', {
    name: 'Kuchnia', floor: 'Parter', bgColor: '#211a14', fg: '#40342a', fallFade: 30,   // trapdoor fall: 500 ms fade
    platforms: rects([[0, 650, 520, 70], [820, 650, 460, 70], CEIL]),   // the trapdoor itself is added by rooms.js while it is closed
    deco: [[420, 480, 480, 20, '#2f261e'], [980, 140, 150, 170, '#4a3320']],   // a shelf on the back wall, a window
    spawns: { default: sp(60), fromSalon: sp(40), fromHall: sp(400) },
    exits: [edge('left', 'salon', 'fromKuchnia')],
    props: [
      { kind: 'trapdoor', x: 520, y: 650, w: 300, h: 70, open: 180, cooldown: 480 },   // open 3 s, lever cooldown 8 s
      { kind: 'fusebox', x: 100, y: 560, w: 40, h: 56 },
      { kind: 'crafting', x: 200, y: 600, w: 90, h: 50 },
      // DECISION: przedpokoj and salon both lead "left" into the kitchen, so the hall is a back-wall door; the boss chase enters here, left of the trapdoor
      door(300, 'Drzwi do przedpokoju', 'przedpokoj', 'fromKuchnia'),
      { kind: 'lever', x: 1180, y: 600, w: 24, h: 48 }
    ],
    items: [{ id: 'note_02', x: 960, y: 634 }]
  });

  R.registerRoom('przedpokoj', {
    name: 'Przedpokój', floor: 'Parter', bgColor: '#1a1a1d', fg: '#35353b',
    platforms: rects([FLOOR, CEIL, [560, 575, 180, 16]]),
    deco: [[790, 230, 90, 140, '#2a2a30']],   // a mirror
    spawns: { default: sp(250), fromKuchnia: sp(1200), fromBath: sp(430), fromCellar: sp(250) },
    exits: [edge('right', 'kuchnia', 'fromHall')],
    props: [
      stairs(90, 'Schody do piwnicy', 'piwnica_main', 'fromHall', null, 'down'),
      door(330, 'Drzwi do łazienki', 'lazienka_parter'),
      { kind: 'chained', x: 1040, y: 500, w: 90, h: 150 }   // the front door: chained for the whole chapter (sequel tease)
    ],
    items: [{ id: 'note_03', x: 480, y: 634 }, { id: 'crowbar', x: 640, y: 559 }, { id: 'candle', x: 900, y: 634 }]
  });

  R.registerRoom('lazienka_parter', {
    name: 'Łazienka', floor: 'Parter', bgColor: '#18201f', fg: '#33403f',
    platforms: rects([FLOOR, CEIL, [300, 575, 200, 16]]),
    deco: [[760, 520, 260, 130, '#2c3a3a'], [120, 130, 90, 120, '#3a4a4a']],   // a bathtub, a cracked mirror
    spawns: { default: sp(60) },
    exits: [edge('left', 'przedpokoj', 'fromBath')],
    items: [{ id: 'first_aid', x: 360, y: 559 }, { id: 'note_04', x: 560, y: 634 }]
  });

  /* ============================================================ FLOOR 1: PIĘTRO */

  R.registerRoom('sypialnia', {
    name: 'Sypialnia', floor: 'Piętro', bgColor: '#1a1415', fg: '#382c2e', dark: true,
    platforms: rects([FLOOR, CEIL, [420, 590, 220, 60]]),   // the bed
    deco: [[900, 150, 130, 190, '#3a2a2a']],
    spawns: { default: sp(210), fromStairs: sp(210), fromBath: sp(350), fromNursery: sp(1220) },
    exits: [edge('right', 'pokoj_dzieciecy', 'fromBedroom')],
    props: [
      stairs(60, 'Schody na parter', 'salon', 'fromStairs', null, 'down'),
      door(260, 'Drzwi do łazienki', 'lazienka_pietro')   // DECISION: the bathroom is a back-wall door (its own "left" exit would clash with the stairs)
    ],
    items: [{ id: 'note_05', x: 520, y: 574 }],
    enemies: [{ type: 'zombie', x: 860, y: 598, drop: 'gabinet_key' }]
  });

  R.registerRoom('pokoj_dzieciecy', {
    name: 'Pokój dziecięcy', floor: 'Piętro', bgColor: '#1f1a22', fg: '#3d3446',
    platforms: rects([FLOOR, CEIL, [380, 590, 100, 60], [600, 575, 180, 16]]),
    deco: [[200, 150, 160, 120, '#3b3050'], [900, 540, 120, 110, '#3a3048']],   // a child's drawing on the wall, a toy chest
    spawns: { default: sp(60), fromBedroom: sp(60), fromStudy: sp(980) },
    exits: [edge('left', 'sypialnia', 'fromNursery')],
    // DECISION: "up" is a staircase straight into the locked gabinet (no polpietro_hall room exists)
    props: [stairs(1040, 'Schody na półpiętro', 'gabinet', 'fromNursery',
      { item: 'gabinet_key', msg: 'Drzwi na półpiętro są zamknięte na klucz.', ok: 'Klucz pasuje. Zamek ustępuje.' }, 'up')],
    items: [{ id: 'note_06', x: 520, y: 634 }, { id: 'teddy_bear', x: 680, y: 559 }]
  });

  R.registerRoom('lazienka_pietro', {
    name: 'Łazienka', floor: 'Piętro', bgColor: '#16201f', fg: '#2f4040',
    platforms: rects([FLOOR, CEIL, [800, 575, 180, 16]]),
    deco: [[200, 520, 240, 130, '#2c3a3a'], [1000, 140, 100, 130, '#3a4a4a']],   // a bathtub, a mirror
    spawns: { default: sp(60) },
    exits: [edge('left', 'sypialnia', 'fromBath')],
    items: [{ id: 'note_07', x: 480, y: 634 }, { id: 'candle', x: 640, y: 634 }]
  });

  /* ============================================================ FLOOR 2: PÓŁPIĘTRO */

  R.registerRoom('gabinet', {
    name: 'Gabinet', floor: 'Półpiętro', bgColor: '#1d1812', fg: '#3b3326',
    platforms: rects([FLOOR, CEIL, [240, 590, 240, 60], [700, 575, 170, 16]]),   // a desk and a shelf
    deco: [[560, 120, 300, 160, '#2c241a']],   // bookshelves
    spawns: { default: sp(210), fromNursery: sp(210), fromStoreroom: sp(1010), fromAttic: sp(1190) },
    props: [
      stairs(60, 'Schody w dół', 'pokoj_dzieciecy', 'fromStudy', null, 'down'),
      // DECISION: the spec gives schowek no door in the gabinet, so it is a crowbar-locked door in the right half
      door(900, 'Drzwi do schowka', 'schowek', 'default',
        { item: 'crowbar', msg: 'Drzwi schowka są zaklinowane. Przydałby się łom.', ok: 'Podważasz drzwi łomem.' }),
      ladder(1100, 'Drabina na strych', 'strych', 'fromStudy', 'up')
    ],
    items: [{ id: 'crossbow', x: 330, y: 574 }, { id: 'bolts', uid: 'bolts_gabinet', x: 770, y: 559 }, { id: 'note_08', x: 560, y: 634 }]
  });

  R.registerRoom('schowek', {
    name: 'Schowek', floor: 'Półpiętro', bgColor: '#16140f', fg: '#34301f', dark: true,
    platforms: rects([FLOOR, CEIL, [300, 575, 200, 16], [700, 575, 200, 16]]),
    deco: [[120, 160, 100, 200, '#24200f']],   // an old wardrobe
    spawns: { default: sp(60) },
    exits: [edge('left', 'gabinet', 'fromStoreroom')],
    items: [
      { id: 'battery', uid: 'battery_1', x: 380, y: 559 }, { id: 'battery', uid: 'battery_2', x: 790, y: 559 },
      { id: 'bolts', uid: 'bolts_schowek', x: 1000, y: 634 }, { id: 'candle', x: 560, y: 634 }
    ]
  });

  /* ============================================================ FLOOR 3-4: STRYCH, PODDASZE */

  R.registerRoom('strych', {
    name: 'Strych', floor: 'Strych', bgColor: '#1a1816', fg: '#3a352e', dark: true,
    // the two off-screen walls keep the crawler inside the room; the player is clamped and never touches them
    platforms: rects([FLOOR, CEIL, [-60, 0, 60, 720], [1280, 0, 60, 720], [220, 575, 200, 16], [480, 500, 180, 16], [900, 575, 200, 16]]),
    deco: [[0, 52, 1280, 10, '#2a2520'], [1000, 100, 90, 120, '#3a2f22']],   // a roof beam, an old trunk
    spawns: { default: sp(190), fromStudy: sp(190), fromCrawl: sp(760) },
    props: [
      ladder(100, 'Drabina w dół', 'gabinet', 'fromAttic', 'down'),
      pass('hatch', 640, 40, 80, 40, 'Klapa na poddasze', 'poddasze', 'default',
        { flag: 'crawlerDead', msg: 'Klapa jest zaklinowana. Coś chodzi po suficie.' }, 'up', 560)
    ],
    items: [{ id: 'note_09', x: 450, y: 634 }],
    enemies: [{ type: 'crawler', x: 700, y: 40 }]
  });

  R.registerRoom('poddasze', {
    name: 'Poddasze', floor: 'Poddasze', bgColor: '#14110e', fg: '#2f2820', dark: true, ambient: true, crouchOnly: true, noBoss: true,
    platforms: rects([FLOOR, [0, 0, 1280, 610]]),   // a 40 px crawlspace: standing (48) does not fit, crouching (24) does
    spawns: { default: sp(240) },
    props: [pass('hatch', 100, 612, 80, 38, 'Klapa na strych', 'strych', 'fromCrawl', null, 'down')],
    items: [{ id: 'note_10', x: 420, y: 634 }, { id: 'valve_handle', x: 980, y: 634 }]
  });

  /* ============================================================ FLOOR -1: PIWNICA */

  R.registerRoom('piwnica_main', {
    name: 'Piwnica', floor: 'Piwnica', bgColor: '#12161a', fg: '#2b333b', dark: true, ambient: true,
    platforms: rects([FLOOR, CEIL, [1010, 0, 270, 618]]),   // the slab leaves a 32 px crawl tunnel to the bunker (the boss squeezes through on its 30 px feet box)
    deco: [[0, 70, 1010, 12, '#1d242b'], [1010, 618, 270, 32, '#07080a']],   // a ceiling pipe, the tunnel mouth
    spawns: { default: sp(345), fromHall: sp(345), fromPantry: sp(40), fromTools: sp(590), fromBoiler: sp(775), fromChute: sp(950), fromBunker: sp(1180) },
    exits: [
      edge('left', 'piwiczka'),
      edge('right', 'bunkier', 'default', { used: 'valve_handle', msg: 'Śluza jest zamknięta. Zawór nie ma korby.' })
    ],
    props: [
      stairs(190, 'Schody na parter', 'przedpokoj', 'fromCellar', null, 'up'),
      door(480, 'Skład narzędzi', 'sklad_narzedzi'),
      door(680, 'Kotłownia', 'kotlownia'),
      stairs(820, 'Schody w dół, do zsypu', 'piwnica_zsyp', 'default', null, 'down', 100),
      { kind: 'valve', x: 1196, y: 590, w: 40, h: 60, item: 'valve_handle', hold: 120, label: 'Zawór śluzy' }   // hold [E] for 2 s
    ],
    items: [{ id: 'note_11', x: 100, y: 634 }, { id: 'candle', x: 400, y: 634 }]
  });

  R.registerRoom('sklad_narzedzi', {
    name: 'Skład narzędzi', floor: 'Piwnica', bgColor: '#17140f', fg: '#352f24', dark: true, ambient: true,
    platforms: rects([FLOOR, CEIL, [300, 575, 180, 16], [560, 500, 160, 16], [820, 575, 180, 16]]),   // benches to jump onto while the webs fly
    deco: [[1060, 160, 140, 190, '#221d14']],   // a tool wall
    spawns: { default: sp(80) },
    // DECISION: the spec says the exit opens on the tarantula's death, so the door seals behind you until then
    exits: [edge('left', 'piwnica_main', 'fromTools', { flag: 'tarantulaDead', msg: 'Drzwi zatrzasnęły się za tobą. Nie ma odwrotu.' })],
    items: [{ id: 'note_12', x: 200, y: 634 }],
    enemies: [{ type: 'tarantula', x: 900, y: 620 }]
  });

  R.registerRoom('kotlownia', {
    name: 'Kotłownia', floor: 'Piwnica', bgColor: '#1a1210', fg: '#3d2c26', ambient: true,
    platforms: rects([FLOOR, CEIL, [200, 575, 160, 16]]),
    deco: [[880, 150, 240, 360, '#2a1c17'], [130, 90, 1020, 12, '#2a1c17']],   // the boiler, a steam pipe
    hazards: [
      { kind: 'steam', x: 450, y: 500, w: 60, h: 150, on: 120, off: 180, at: 0 },     // 2 s on, 3 s off
      { kind: 'steam', x: 760, y: 500, w: 60, h: 150, on: 120, off: 180, at: 150 }    // DECISION: offset by half a cycle so the jets alternate
    ],
    spawns: { default: sp(80) },
    exits: [edge('left', 'piwnica_main', 'fromBoiler')],
    items: [{ id: 'note_13', x: 260, y: 559 }, { id: 'fuse', x: 1000, y: 634 }, { id: 'vial', x: 1150, y: 634 }]
  });

  R.registerRoom('piwiczka', {
    name: 'Piwiczka', floor: 'Piwnica', bgColor: '#15180f', fg: '#2f3624', dark: true, ambient: true,
    platforms: rects([FLOOR, CEIL, [300, 575, 160, 16], [900, 575, 160, 16]]),
    deco: [[560, 380, 240, 270, '#1e2316']],   // racks of old jars
    spawns: { default: sp(1190) },
    exits: [edge('right', 'piwnica_main', 'fromPantry')],
    items: [{ id: 'trucizna', x: 360, y: 559 }, { id: 'note_14', x: 800, y: 634 }]
  });

  R.registerRoom('piwnica_zsyp', {
    name: 'Zsyp', floor: 'Piwnica', bgColor: '#10121a', fg: '#262b3a', dark: true, ambient: true,
    platforms: rects([FLOOR, CEIL]),
    chute: { x1: 660, y1: 40, x2: 900, y2: 470, w: 110 },   // the slide from the kitchen ceiling to the cage mouth
    cage: { x: 800, y: 430, w: 380, h: 220 },               // open until the boss lands, then the bars slam shut
    spawns: { default: sp(210), fromChute: sp(210), cutscene: sp(400) },
    props: [stairs(60, 'Schody w górę', 'piwnica_main', 'fromChute', null, 'up')]
  });

  /* ============================================================ FLOOR -2: BUNKIER */

  R.registerRoom('bunkier', {
    name: 'Bunkier', floor: 'Bunkier', bgColor: '#0f0f13', fg: '#25252d', dark: true, ambient: true, crouchOnly: true,
    // DECISION: the bunker is tall (the boss is 90 px) and the crouch comes from the room flag; the boss was born here, so only poddasze bars it
    platforms: rects([FLOOR, CEIL]),
    deco: [[940, 160, 300, 490, '#17262a'], [330, 300, 90, 350, '#1c1c24'], [0, 636, 1280, 14, '#3a3510']],   // the empty containment tank, lockers, hazard stripe
    bossHome: { x: 1000, y: 560 },
    spawns: { default: sp(60) },
    exits: [edge('left', 'piwnica_main', 'fromBunker')],
    items: [{ id: 'note_15', x: 170, y: 634 }]   // close to the entrance: read it, then leave before the boss finishes growling
  });
})(window.ZSYP = window.ZSYP || {});