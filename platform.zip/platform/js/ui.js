// FILE: js/ui.js
/*
 * All interface drawing and screen logic: HUD, main menu, pause, Tab inventory + journal, note viewer, death, win.
 * Screens follow the contract in main.js: Z.UI.screens[state] = { update(g) -> action|undefined, draw(ctx, g) }.
 * Georgia (serif fallback) is used everywhere: it ships with Windows and macOS and has every Polish diacritic.
 * Room data supplies room.name and room.floor (Polish) for the top-right label.
 */
(function (Z) {
  'use strict';

  var W = 1280, H = 720;
  var FONT = 'Georgia, "Times New Roman", serif';
  var INK = '#d9d2c3', DIM = '#8d867a', BLOOD = '#8c1c1c', BLOOD_HI = '#c0392b';
  var ROWS = 11;                                           // visible journal rows
  var WIN_LINE = 'UWIĘZIONY. Na razie. — Koniec rozdziału 1.';
  var DEATH_LINES = ['Ciemność zamknęła się nad tobą.', 'To coś było szybsze.', 'Dom zapamięta jeszcze jedno imię.', 'Nikt nie usłyszał krzyku.'];
  var CONTROLS = [
    ['A/D lub ←/→ — ruch', 'Spacja, W lub ↑ — skok', 'Shift lub C — kucanie'],
    ['J lub LPM — atak', 'Q — zmiana broni', 'E — interakcja'],
    ['F — latarka', 'Tab — ekwipunek i dziennik', 'Esc — pauza']
  ];
  /** Inventory tooltips. Unknown ids (sequel items) simply show no description. */
  var ITEM_INFO = {
    flashlight: 'Klawisz F włącza i wyłącza światło. Bateria wyczerpuje się z czasem.',
    battery: 'Użyj, aby doładować latarkę o 40%.',
    first_aid: 'Użyj, aby odzyskać 40 punktów zdrowia.',
    crowbar: 'Wyważysz nim zaklinowane drzwi schowka.',
    gabinet_key: 'Klucz do gabinetu na górze.',
    key_chute: 'Klucz do mechanizmu zsypu w kuchni.',
    valve_handle: 'Korba zaworu śluzy bunkra.',
    fuse: 'Pasuje do skrzynki bezpieczników w kuchni.',
    vial: 'Mętna ciecz. Potrzebna do trucizny przy kuchennym stole.',
    teddy_bear: 'Miś Stasia. Nie potrafisz go tu zostawić.'
  };

  var ui = {
    menu: { sel: 0, mx: -1, my: -1 },
    paused: { sel: 0, mx: -1, my: -1 },
    dead: { sel: 0, mx: -1, my: -1, t: 0, line: '' },
    win: { sel: 0, mx: -1, my: -1, t: 0 },
    note: { t: 0 },
    journal: { focus: 'items', slot: 0, note: 0, top: 0, msg: '', msgT: 0, mx: -1, my: -1 }
  };
  var seen = {}, wrapCache = {}, wheel = 0, wheelBound = false;
  var screens = {};

  /* ---------------------------------------------------------------- shared helpers */

  function setFont(ctx, size, weight) { ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + FONT; }

  /** One line of text. `weight` may be 'bold', 'italic' or 'italic bold'. */
  function txt(ctx, s, x, y, size, color, align, weight) {
    setFont(ctx, size, weight);
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = color || INK;
    ctx.fillText(s, x, y);
  }

  function dim(ctx, a) { ctx.fillStyle = 'rgba(0,0,0,' + a.toFixed(3) + ')'; ctx.fillRect(0, 0, W, H); }

  function panel(ctx, x, y, w, h, fill, edge) {
    ctx.fillStyle = fill || 'rgba(10,8,8,0.93)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = edge || 'rgba(217,210,195,0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  function bar(ctx, x, y, w, h, frac, fill, back) {
    ctx.fillStyle = back; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = fill; ctx.fillRect(x, y, Math.max(0, Math.min(1, frac)) * w, h);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  function inside(mo, r) { return mo.x >= r.x && mo.x <= r.x + r.w && mo.y >= r.y && mo.y <= r.y + r.h; }

  /** Word-wraps with the font currently set on ctx; results are cached because the text never changes. */
  function wrap(ctx, text, maxW) {
    var key = ctx.font + '|' + maxW + '|' + text, words, lines, line, i, test;
    if (wrapCache[key]) return wrapCache[key];
    words = text.split(' '); lines = []; line = '';
    for (i = 0; i < words.length; i++) {
      test = line ? line + ' ' + words[i] : words[i];
      if (line && ctx.measureText(test).width > maxW) { lines.push(line); line = words[i]; } else line = test;
    }
    if (line) lines.push(line);
    wrapCache[key] = lines;
    return lines;
  }

  /** True on the first update after a screen appeared (screens are only updated while active, so a gap means "just opened"). */
  function opened(key) {
    var now = performance.now(), fresh = !seen[key] || now - seen[key] > 250;
    seen[key] = now;
    return fresh;
  }

  /** The mouse wheel scrolls the journal list; bound lazily because the canvas only exists after boot. */
  function bindWheel(g) {
    if (wheelBound || !g.canvas) return;
    wheelBound = true;
    g.canvas.addEventListener('wheel', function (e) { e.preventDefault(); wheel += e.deltaY > 0 ? 1 : -1; }, { passive: false });
  }

  /* ---------------------------------------------------------------- buttons (keyboard + mouse) */

  function layoutButtons(items, x, y, w, h, gap) {
    return items.map(function (it, i) {
      return { label: it.label, action: it.action, enabled: it.enabled !== false, x: x, y: y + i * (h + gap), w: w, h: h };
    });
  }

  function nextEnabled(buttons, from, dir) {
    var n = buttons.length, i = from, k;
    for (k = 0; k < n; k++) { i = (i + dir + n) % n; if (buttons[i].enabled) return i; }
    return from;
  }

  /**
   * Shared button-list input: W/S or arrows move, Enter/Space/E confirm, the mouse hovers and clicks.
   * Hover only changes the selection when the mouse actually moved, so it cannot fight the keyboard.
   * @returns {string|null} the chosen button's action
   */
  function pick(key, buttons) {
    var In = Z.Input, m = ui[key], mo = In.mouse, hit = -1, i, clicked;
    for (i = 0; i < buttons.length; i++) if (buttons[i].enabled && inside(mo, buttons[i])) hit = i;
    if (mo.x !== m.mx || mo.y !== m.my) { m.mx = mo.x; m.my = mo.y; if (hit >= 0) m.sel = hit; }
    if (In.pressed('down')) m.sel = nextEnabled(buttons, m.sel, 1);
    if (In.pressed('up')) m.sel = nextEnabled(buttons, m.sel, -1);
    clicked = In.pressed('attack') && hit >= 0;
    if (clicked) m.sel = hit;
    if ((In.pressed('confirm') || clicked) && buttons[m.sel] && buttons[m.sel].enabled) {
      Z.Audio.play('click');
      return buttons[m.sel].action;
    }
    return null;
  }

  function drawButton(ctx, b, selected) {
    ctx.save();
    ctx.globalAlpha *= b.enabled ? 1 : 0.35;
    ctx.fillStyle = selected ? 'rgba(140,28,28,0.55)' : 'rgba(0,0,0,0.55)';
    ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.strokeStyle = selected ? BLOOD_HI : 'rgba(217,210,195,0.35)';
    ctx.lineWidth = selected ? 2 : 1;
    ctx.strokeRect(b.x + 0.5, b.y + 0.5, b.w - 1, b.h - 1);
    txt(ctx, b.label, b.x + b.w / 2, b.y + b.h / 2 + 9, 26, selected ? '#fff' : INK, 'center');
    ctx.restore();
  }

  /* ---------------------------------------------------------------- HUD */

  function iconKnife(ctx, x, y) {                          // drawn inside a 56x40 box
    ctx.save();
    ctx.translate(x + 28, y + 20);
    ctx.rotate(-0.45);
    ctx.fillStyle = '#5b3a24'; ctx.fillRect(-26, -4, 18, 8);          // handle
    ctx.fillStyle = '#8a8f99'; ctx.fillRect(-9, -7, 3, 14);           // guard
    ctx.fillStyle = '#d4d8de';
    ctx.beginPath(); ctx.moveTo(-6, -4); ctx.lineTo(18, -4); ctx.lineTo(28, 2); ctx.lineTo(-6, 4); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  function iconCrossbow(ctx, x, y) {
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#8a6a40'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(x + 4, y + 24); ctx.lineTo(x + 46, y + 20); ctx.stroke();                            // stock
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(x + 34, y + 4); ctx.quadraticCurveTo(x + 52, y + 21, x + 34, y + 38); ctx.stroke();  // limbs
    ctx.strokeStyle = '#cfc6b0'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x + 34, y + 4); ctx.lineTo(x + 24, y + 21); ctx.lineTo(x + 34, y + 38); ctx.stroke(); // drawn string
    ctx.strokeStyle = '#e8e2d0'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x + 24, y + 21); ctx.lineTo(x + 48, y + 21); ctx.stroke();                           // bolt
    ctx.restore();
  }

  /**
   * In-game HUD: HP + stamina (top-left), floor + room (top-right), weapon + ammo (bottom-left),
   * toast and [E] prompt (bottom-centre), crosshair dot (centre, crossbow only).
   */
  function hud(ctx, g) {
    var p = g.player, inv = g.inv, room = g.room, hasLight = Z.Player.hasItem(g, 'flashlight');
    var a, rg, bx = 20, by = H - 66, w;
    ctx.save();

    if (p.hp < 30) {                                       // DECISION: pulsing red screen edge when badly hurt (feedback only, no rule change)
      a = 0.45 * (1 - p.hp / 30) * (0.6 + 0.4 * Math.sin(g.time * (0.1 + (30 - p.hp) * 0.004)));
      rg = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.85);
      rg.addColorStop(0, 'rgba(120,0,0,0)');
      rg.addColorStop(1, 'rgba(120,0,0,' + a.toFixed(3) + ')');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
    }

    bar(ctx, 20, 20, 200, 16, p.hp / 100, p.iframes > 0 ? '#e0504f' : '#b3262b', '#2a0b0c');
    txt(ctx, String(Math.ceil(p.hp)), 26, 33, 12, '#fff', 'left');
    bar(ctx, 20, 42, 200, 12, p.stamina / 100, '#3fae4a', '#0c220f');
    // DECISION: a thin battery bar under stamina once the flashlight is found; it adds tension without a new mechanic
    if (hasLight) bar(ctx, 20, 60, 200, 6, p.battery / 100, p.battery < 20 ? '#c0392b' : (p.flashlightOn ? '#f0d860' : '#8a7a30'), '#2a2408');

    txt(ctx, room.floor || '', W - 24, 30, 15, DIM, 'right', 'italic');
    txt(ctx, room.name || g.roomId, W - 24, 58, 26, INK, 'right');

    panel(ctx, bx, by, 250, 46, 'rgba(0,0,0,0.55)', 'rgba(217,210,195,0.2)');
    if (p.weapon === 'crossbow') {
      iconCrossbow(ctx, bx + 6, by + 3);
      txt(ctx, 'Kusza', bx + 70, by + 20, 14, DIM, 'left', 'italic');
      txt(ctx, inv.ammo.bolts + '/10', bx + 70, by + 40, 20, inv.ammo.bolts > 0 ? INK : BLOOD_HI, 'left');
      if (inv.ammo.poisoned > 0) txt(ctx, 'zatrute: ' + inv.ammo.poisoned, bx + 130, by + 40, 16, '#8fd14f', 'left');
    } else {
      iconKnife(ctx, bx + 6, by + 3);
      txt(ctx, 'Nóż', bx + 70, by + 20, 14, DIM, 'left', 'italic');
      txt(ctx, '∞', bx + 70, by + 40, 22, INK, 'left');
    }

    if (g.toast) {
      ctx.globalAlpha = Math.min(1, g.toast.t / 30);
      setFont(ctx, 20);
      w = ctx.measureText(g.toast.text).width + 40;
      panel(ctx, (W - w) / 2, H - 150, w, 38, 'rgba(0,0,0,0.7)', 'rgba(217,210,195,0.2)');
      txt(ctx, g.toast.text, W / 2, H - 124, 20, INK, 'center');
      ctx.globalAlpha = 1;
    }
    if (g.prompt) {
      setFont(ctx, 22);
      w = ctx.measureText(g.prompt).width + 40;
      panel(ctx, (W - w) / 2, H - 98, w, 40, 'rgba(0,0,0,0.7)', 'rgba(217,210,195,0.35)');
      txt(ctx, g.prompt, W / 2, H - 70, 22, '#fff', 'center');
    }
    if (g.holdP > 0) bar(ctx, W / 2 - 80, H - 46, 160, 8, g.holdP, '#c9a64a', '#2a2208');   // hold-E progress (bunker valve)

    if (p.weapon === 'crossbow') {                         // spec: small dot at the centre of the screen
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.beginPath(); ctx.arc(W / 2, H / 2, 2.5, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(W / 2, H / 2, 7, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }

  /* ---------------------------------------------------------------- main menu */

  function menuButtons() {
    return layoutButtons([
      { label: 'Nowa gra', action: 'new' },
      { label: 'Wczytaj zapis', action: 'load', enabled: Z.Save.has() }
    ], 110, 380, 340, 54, 14);
  }

  /** Falling ash (nuclear winter). Positions are pure functions of time, so no particle state is needed. */
  function drawAsh(ctx, t) {
    var i, sx, sy, x, y, s;
    ctx.fillStyle = 'rgba(200,200,200,0.5)';
    for (i = 0; i < 70; i++) {
      sx = (i * 97.13) % 1; sy = (i * 61.7) % 1; s = 2 + (i % 3);
      x = (sx * W + Math.sin(t * 0.4 + i) * 30 + t * (8 + (i % 5) * 3)) % W;
      y = (sy * H + t * (22 + (i % 7) * 6)) % H;
      ctx.fillRect(x, y, s, s);
    }
  }

  /** The house silhouette with one flickering lit window. */
  function drawHouse(ctx, t) {
    var f = 0.55 + 0.25 * Math.sin(t * 7) * Math.sin(t * 2.3) - (Math.sin(t * 31) > 0.93 ? 0.4 : 0);
    ctx.fillStyle = '#050608';
    ctx.fillRect(760, 450, 380, 180);
    ctx.beginPath(); ctx.moveTo(730, 450); ctx.lineTo(950, 350); ctx.lineTo(1170, 450); ctx.closePath(); ctx.fill();
    ctx.fillRect(1060, 365, 34, 80);
    ctx.fillRect(0, 630, W, 90);
    ctx.fillStyle = 'rgba(214,160,70,' + Math.max(0.05, f).toFixed(2) + ')';
    ctx.fillRect(800, 500, 46, 56);
    ctx.fillStyle = '#10131a';
    ctx.fillRect(1040, 500, 46, 56);
    ctx.fillRect(930, 548, 40, 82);
  }

  /** Blood-red title with dripping streaks and a rare flicker. */
  function drawTitle(ctx, t) {
    var i, dx, len;
    ctx.save();
    ctx.globalAlpha = (Math.sin(t * 40) * Math.sin(t * 1.7) > 0.93) ? 0.35 : 1;
    txt(ctx, 'ZSYP', 104, 250, 170, BLOOD, 'left', 'bold');
    ctx.fillStyle = BLOOD;
    for (i = 0; i < 6; i++) {
      dx = 118 + i * 63 + (i % 2) * 14;
      len = 26 + 18 * (0.5 + 0.5 * Math.sin(t * 0.6 + i * 1.9));
      ctx.fillRect(dx, 252, 4, len);
      ctx.beginPath(); ctx.arc(dx + 2, 252 + len, 4, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  screens.menu = {
    update: function () {
      var b = menuButtons();
      if (opened('menu')) { ui.menu.sel = b[1].enabled ? 1 : 0; ui.menu.mx = -1; ui.menu.my = -1; }   // default to the save if one exists
      return pick('menu', b);
    },
    draw: function (ctx) {
      var t = performance.now() / 1000, b = menuButtons(), i, j, grd = ctx.createLinearGradient(0, 0, 0, H);
      grd.addColorStop(0, '#05060a'); grd.addColorStop(0.7, '#14100f'); grd.addColorStop(1, '#050505');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, W, H);
      drawHouse(ctx, t);
      drawAsh(ctx, t);
      drawTitle(ctx, t);
      txt(ctx, 'Rozdział 1', 112, 296, 30, DIM, 'left', 'italic');
      for (i = 0; i < b.length; i++) drawButton(ctx, b[i], i === ui.menu.sel);
      txt(ctx, 'Sprint: dwukrotnie wciśnij kierunek i przytrzymaj.', 110, H - 82, 15, DIM, 'left', 'italic');
      for (i = 0; i < CONTROLS.length; i++) for (j = 0; j < CONTROLS[i].length; j++) {
        txt(ctx, CONTROLS[i][j], 110 + i * 370, H - 60 + j * 22, 16, DIM, 'left');
      }
    }
  };

  /* ---------------------------------------------------------------- pause */

  function pauseButtons() {
    return layoutButtons([
      { label: 'Wznów', action: 'resume' },
      { label: 'Wczytaj zapis', action: 'load', enabled: Z.Save.has() },
      { label: 'Menu główne', action: 'menu' }
    ], (W - 340) / 2, 300, 340, 54, 14);
  }

  screens.paused = {
    update: function () {
      if (opened('paused')) { ui.paused.sel = 0; ui.paused.mx = -1; ui.paused.my = -1; }
      if (Z.Input.pressed('pause')) return 'resume';
      return pick('paused', pauseButtons());
    },
    draw: function (ctx) {
      var b = pauseButtons(), i;
      dim(ctx, 0.72);
      txt(ctx, 'Pauza', W / 2, 250, 72, INK, 'center', 'bold');
      for (i = 0; i < b.length; i++) drawButton(ctx, b[i], i === ui.paused.sel);
      txt(ctx, 'Postęp zapisujesz przy świecach.', W / 2, 560, 18, DIM, 'center', 'italic');
    }
  };

  /* ---------------------------------------------------------------- Tab: inventory grid + journal */

  function slotRect(i) { return { x: 100 + (i % 2) * 184, y: 130 + Math.floor(i / 2) * 106, w: 170, h: 92 }; }
  function noteRect(row) { return { x: 520, y: 130 + row * 34, w: 240, h: 32 }; }

  function keepVisible(j, n) {
    if (j.note < j.top) j.top = j.note;
    if (j.note >= j.top + ROWS) j.top = j.note - ROWS + 1;
    j.top = Math.max(0, Math.min(j.top, Math.max(0, n - ROWS)));
  }

  function useSlot(g, j) {
    var id = g.inv.items[j.slot], def = id && Z.Items.ITEMS[id], msg;
    if (!def) return;
    msg = Z.Inventory.use(g, j.slot);                      // spends consumables, explains the rest
    if (!msg) return;
    j.msg = msg; j.msgT = 240;
    Z.Items.say(g, msg);
    Z.Audio.play(def.use ? 'pickup' : 'click');
  }

  screens.journal = {
    update: function (g) {
      var In = Z.Input, j = ui.journal, mo = In.mouse, notes = Z.Inventory.noteList(g), i, hit = null, moved;
      bindWheel(g);
      if (opened('journal')) {
        j.focus = 'items'; j.slot = 0; j.msg = ''; j.msgT = 0; j.mx = -1; j.my = -1; wheel = 0; j.note = 0;
        for (i = 0; i < notes.length; i++) if (notes[i].id === g.noteId) j.note = i;   // open on the note read last
        j.top = 0;
        keepVisible(j, notes.length);
      }
      if (In.pressed('inventory') || In.pressed('pause')) return 'close';
      if (j.msgT > 0) j.msgT--;
      if (wheel) { j.top = Math.max(0, Math.min(j.top + wheel, Math.max(0, notes.length - ROWS))); wheel = 0; }

      if (j.focus === 'items') {                           // 2 columns x 3 rows; right from the right column enters the journal
        if (In.pressed('up') && j.slot >= 2) j.slot -= 2;
        if (In.pressed('down') && j.slot <= 3) j.slot += 2;
        if (In.pressed('left') && j.slot % 2 === 1) j.slot -= 1;
        if (In.pressed('right')) { if (j.slot % 2 === 0) j.slot += 1; else if (notes.length) j.focus = 'notes'; }
        if (In.pressed('confirm')) useSlot(g, j);
      } else {
        if (In.pressed('up') && j.note > 0) j.note--;
        if (In.pressed('down') && j.note < notes.length - 1) j.note++;
        if (In.pressed('left')) { j.focus = 'items'; j.slot = 1; }
        keepVisible(j, notes.length);
      }

      moved = mo.x !== j.mx || mo.y !== j.my;
      j.mx = mo.x; j.my = mo.y;
      for (i = 0; i < Z.Inventory.SLOTS; i++) if (inside(mo, slotRect(i))) hit = { kind: 'slot', i: i };
      for (i = 0; i < Math.min(ROWS, notes.length - j.top); i++) if (inside(mo, noteRect(i))) hit = { kind: 'note', i: j.top + i };
      if (hit && (moved || In.pressed('attack'))) {
        if (hit.kind === 'slot') { j.focus = 'items'; j.slot = hit.i; } else { j.focus = 'notes'; j.note = hit.i; }
      }
      if (hit && hit.kind === 'slot' && In.pressed('attack')) useSlot(g, j);
      return undefined;
    },
    draw: function (ctx, g) {
      var j = ui.journal, v = g.inv, p = g.player, notes = Z.Inventory.noteList(g), i, r, id, d, sel, lines, y, n, by;
      dim(ctx, 0.84);
      panel(ctx, 70, 50, 1140, 620);
      txt(ctx, 'Ekwipunek', 100, 104, 30, INK, 'left', 'bold');
      txt(ctx, 'Dziennik', 520, 104, 30, INK, 'left', 'bold');

      for (i = 0; i < Z.Inventory.SLOTS; i++) {
        r = slotRect(i); id = v.items[i]; sel = j.focus === 'items' && j.slot === i;
        panel(ctx, r.x, r.y, r.w, r.h, sel ? 'rgba(140,28,28,0.45)' : 'rgba(255,255,255,0.04)', sel ? BLOOD_HI : 'rgba(217,210,195,0.2)');
        if (!id) continue;
        d = Z.Items.ITEMS[id];
        ctx.fillStyle = d ? d.color : '#888';
        ctx.fillRect(r.x + r.w / 2 - 14, r.y + 14, 28, 28);
        ctx.strokeStyle = 'rgba(0,0,0,0.7)'; ctx.lineWidth = 1;
        ctx.strokeRect(r.x + r.w / 2 - 13.5, r.y + 14.5, 27, 27);
        txt(ctx, d ? d.name : id, r.x + r.w / 2, r.y + 72, 16, INK, 'center');
      }

      panel(ctx, 100, 446, 354, 92, 'rgba(0,0,0,0.35)', 'rgba(217,210,195,0.15)');   // description / last message
      if (j.msgT > 0) {
        setFont(ctx, 17); lines = wrap(ctx, j.msg, 330);
        for (i = 0; i < lines.length; i++) txt(ctx, lines[i], 112, 474 + i * 22, 17, '#e3c77a', 'left');
      } else if (j.focus === 'items' && v.items[j.slot]) {
        id = v.items[j.slot]; d = Z.Items.ITEMS[id];
        txt(ctx, d ? d.name : id, 112, 470, 18, INK, 'left', 'bold');
        setFont(ctx, 15); lines = wrap(ctx, ITEM_INFO[id] || '', 330);
        for (i = 0; i < lines.length; i++) txt(ctx, lines[i], 112, 492 + i * 18, 15, DIM, 'left');
      } else {
        txt(ctx, 'Wybierz przedmiot.', 112, 478, 16, DIM, 'left', 'italic');
      }

      y = 566;
      txt(ctx, 'Zdrowie: ' + Math.ceil(p.hp) + '/100', 100, y, 17, INK); y += 22;
      txt(ctx, 'Broń: ' + (p.weapon === 'crossbow' ? 'Kusza' : 'Nóż') +
        (v.weapons.indexOf('crossbow') >= 0 ? '   Bełty: ' + v.ammo.bolts + '/10   zatrute: ' + v.ammo.poisoned : ''), 100, y, 17, INK); y += 22;
      if (Z.Player.hasItem(g, 'flashlight')) { txt(ctx, 'Latarka: ' + Math.round(p.battery) + '%', 100, y, 17, INK); y += 22; }
      if (v.poisonBottle) { txt(ctx, 'Masz butelkę trucizny.', 100, y, 17, '#8fd14f'); y += 22; }
      txt(ctx, 'Notatki: ' + notes.length + '/15', 100, y, 17, DIM);

      n = Math.min(ROWS, notes.length - j.top);
      for (i = 0; i < n; i++) {
        r = noteRect(i); sel = (j.top + i) === j.note;
        panel(ctx, r.x, r.y, r.w, r.h,
          sel ? (j.focus === 'notes' ? 'rgba(140,28,28,0.45)' : 'rgba(255,255,255,0.08)') : 'rgba(255,255,255,0.03)',
          sel && j.focus === 'notes' ? BLOOD_HI : 'rgba(217,210,195,0.15)');
        txt(ctx, notes[j.top + i].title, r.x + 12, r.y + 22, 18, sel ? '#fff' : INK, 'left');
      }
      ctx.fillStyle = DIM;                                 // scroll arrows
      if (j.top > 0) { ctx.beginPath(); ctx.moveTo(772, 130); ctx.lineTo(780, 142); ctx.lineTo(764, 142); ctx.closePath(); ctx.fill(); }
      if (j.top + ROWS < notes.length) {
        by = 130 + ROWS * 34 - 8;
        ctx.beginPath(); ctx.moveTo(764, by); ctx.lineTo(780, by); ctx.lineTo(772, by + 12); ctx.closePath(); ctx.fill();
      }
      if (!notes.length) txt(ctx, 'Brak notatek.', 520, 160, 20, DIM, 'left', 'italic');
      else {
        d = Z.Inventory.NOTES[notes[j.note].id];
        txt(ctx, notes[j.note].title, 800, 144, 24, INK, 'left', 'bold');
        setFont(ctx, 19); lines = wrap(ctx, d.text, 380);
        ctx.fillStyle = INK; ctx.textAlign = 'left';
        for (i = 0; i < lines.length; i++) ctx.fillText(lines[i], 800, 186 + i * 27);
      }
      txt(ctx, 'Strzałki lub WASD — wybór     Enter, E lub kliknięcie — użyj     Tab lub Esc — zamknij', W / 2, 700, 16, DIM, 'center');
    }
  };

  /* ---------------------------------------------------------------- note viewer (opened by picking up a note) */

  function noteLines(ctx, id) {
    var def = Z.Inventory.NOTES[id];
    setFont(ctx, 22);
    return def ? wrap(ctx, def.text, 600) : [];
  }

  function countChars(lines) {
    var n = 0, i;
    for (i = 0; i < lines.length; i++) n += lines[i].length;
    return n;
  }

  screens.note = {
    update: function (g) {
      var n = ui.note, In = Z.Input, total;
      if (opened('note')) n.t = 0;
      n.t++;
      total = countChars(noteLines(g.ctx, g.noteId));
      if (In.pressed('confirm') || In.pressed('pause') || In.pressed('attack') || In.pressed('inventory')) {
        if (n.t * 2.2 < total) n.t = Math.ceil(total / 2.2) + 1;     // first press shows the whole note, the second closes it
        else return 'close';
      }
      return undefined;
    },
    draw: function (ctx, g) {
      var n = ui.note, def = Z.Inventory.NOTES[g.noteId] || { title: '', text: '' };
      var lines = noteLines(ctx, g.noteId), total = countChars(lines), left = Math.floor(n.t * 2.2), done = left >= total, i, s;
      dim(ctx, 0.72);
      ctx.save();                                          // parchment with two stains
      ctx.fillStyle = '#d6c9a4'; ctx.fillRect(290, 70, 700, 580);
      ctx.fillStyle = 'rgba(120,90,50,0.12)';
      ctx.beginPath(); ctx.ellipse(420, 540, 90, 60, 0.4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(880, 160, 70, 40, -0.3, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#3b2c1a'; ctx.lineWidth = 3; ctx.strokeRect(290.5, 70.5, 699, 579);
      ctx.restore();
      txt(ctx, 'Notatka ' + (parseInt(String(g.noteId).slice(5), 10) || 0) + ' z 15', 330, 118, 18, '#6b5a3c', 'left', 'italic');
      txt(ctx, def.title, 330, 166, 34, '#2a1d10', 'left', 'bold');
      setFont(ctx, 22); ctx.fillStyle = '#2a1d10'; ctx.textAlign = 'left';
      for (i = 0; i < lines.length && left > 0; i++) {     // typewriter reveal
        s = lines[i].slice(0, left); left -= lines[i].length;
        ctx.fillText(s, 330, 222 + i * 32);
      }
      txt(ctx, done ? '[E] Zamknij' : '[E] Pokaż całość', 640, 620, 18, '#6b5a3c', 'center', 'italic');
    }
  };

  /* ---------------------------------------------------------------- death + win */

  function deadButtons() {
    return layoutButtons([
      { label: 'Wczytaj zapis', action: 'load', enabled: Z.Save.has() },
      { label: 'Nowa gra', action: 'new' }
    ], (W - 340) / 2, 410, 340, 54, 14);
  }

  screens.dead = {
    update: function () {
      var d = ui.dead;
      if (opened('dead')) {
        d.t = 0; d.mx = -1; d.my = -1;
        d.sel = Z.Save.has() ? 0 : 1;
        d.line = DEATH_LINES[Math.floor(Math.random() * DEATH_LINES.length)];
      }
      d.t++;
      return d.t < 45 ? null : pick('dead', deadButtons());   // short input lock: a panicked key-mash must not skip the screen
    },
    draw: function (ctx) {
      var d = ui.dead, t = d.t, b = deadButtons(), i, rg;
      ctx.fillStyle = '#030202'; ctx.fillRect(0, 0, W, H);
      rg = ctx.createRadialGradient(W / 2, H / 2, 120, W / 2, H / 2, 720);
      rg.addColorStop(0, 'rgba(0,0,0,0)');
      rg.addColorStop(1, 'rgba(110,0,0,' + (0.25 + 0.2 * (0.5 + 0.5 * Math.sin(t * 0.05))).toFixed(3) + ')');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
      ctx.save();
      ctx.globalAlpha = Math.min(1, t / 60);
      ctx.shadowColor = '#600'; ctx.shadowBlur = 24;
      txt(ctx, 'Zginąłeś', W / 2, 290, 110, BLOOD, 'center', 'bold');
      ctx.shadowBlur = 0;
      txt(ctx, d.line, W / 2, 350, 26, DIM, 'center', 'italic');
      ctx.globalAlpha = Math.max(0, Math.min(1, (t - 45) / 30));
      for (i = 0; i < b.length; i++) drawButton(ctx, b[i], i === d.sel);
      ctx.restore();
    }
  };

  function winButtons() { return layoutButtons([{ label: 'Nowa gra', action: 'new' }], (W - 340) / 2, 470, 340, 54, 14); }

  screens.win = {
    update: function () {
      var w = ui.win;
      if (opened('win')) { w.t = 0; w.sel = 0; w.mx = -1; w.my = -1; }
      w.t++;
      return w.t < 150 ? null : pick('win', winButtons());  // the line needs time to sink in before the button works
    },
    draw: function (ctx) {
      var w = ui.win, t = w.t, b = winButtons();
      dim(ctx, Math.min(0.9, t / 60));
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, (t - 30) / 60));
      txt(ctx, WIN_LINE, W / 2, 320, 44, '#f0e8d8', 'center', 'bold');
      ctx.globalAlpha = Math.max(0, Math.min(1, (t - 100) / 50));
      txt(ctx, 'Zima nuklearna dopiero się zaczyna.', W / 2, 376, 24, DIM, 'center', 'italic');
      ctx.globalAlpha = Math.max(0, Math.min(1, (t - 130) / 30));
      drawButton(ctx, b[0], true);
      ctx.restore();
    }
  };

  Z.UI = { hud: hud, screens: screens };
})(window.ZSYP = window.ZSYP || {});