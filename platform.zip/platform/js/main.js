// FILE: js/main.js
/*
 * ZSYP (The Chute) — bootstrap, fixed 60 Hz game loop, top-level state machine.
 *
 * MODULE CONTRACT. Every file is a classic <script> that attaches to window.ZSYP (alias Z).
 * `g` below is Z.Game, the one shared object passed to every module.
 *   Z.Input      init(canvas) tick() down(a) held(a) pressed(a) flush() mouse{x,y}
 *   Z.Audio      init() play(name) setMuted(bool) setAmbient(bool)
 *   Z.Render     shake(px,frames) shakeOffset() spark(x,y,n,color) updateParticles() drawParticles(ctx) vignette(ctx,g)
 *   Z.Player     create() update(g) draw(ctx,g) hurt(g,dmg)     (p.x,p.y = top-left corner of the AABB)
 *   Z.Enemies    ENEMIES{type:{create}} update(g) draw(ctx,g)    (g.enemies is filled by Rooms.enter)
 *   Z.Items      ITEMS{id:{pickup,use}} update(g) draw(ctx,g)    (g.items is filled by Rooms.enter)
 *   Z.Inventory  reset(g) -> g.inv = {items, ammo, weapons, poisonBottle, notes, used, taken}
 *   Z.Rooms      ROOMS registerRoom(id,data) enter(g,id,spawn) update(g) draw(ctx,g)
 *   Z.Save       has() write(g) read() apply(g,data)              (apply ends by calling g.enterRoom)
 *   Z.UI         hud(ctx,g) screens{menu,paused,journal,note,dead,win}
 *                each screen = { update(g) -> action|undefined, draw(ctx,g) }
 * Screen actions understood here: 'new' | 'load' | 'resume' | 'close' | 'menu'.
 * Gameplay code talks to the HUD through g.prompt (a string, reset every step).
 */
(function (Z) {
  'use strict';

  var W = 1280, H = 720;
  var STEP = 1000 / 60;   // fixed simulation step in ms: every physics value in the spec is per-frame
  var REQUIRED = ['Input', 'Audio', 'Render', 'Player', 'Enemies', 'Items', 'Inventory', 'Rooms', 'Save', 'UI'];

  /** Shared game object: the single source of truth every module receives as `g`. */
  var g = Z.Game = {
    W: W, H: H, canvas: null, ctx: null,
    state: 'menu',                      // menu | playing | paused | journal | note | dead | win
    room: null, roomId: null, entrance: { x: 0, y: 0 },
    player: null, enemies: [], items: [], inv: null,
    flags: null, prompt: null, noteId: null,
    fade: { phase: 0, t: 0, len: 12, a: 0, cb: null },   // phase 0 idle, 1 fading out, 2 fading in
    dyingT: 0, time: 0
  };

  var acc = 0, last = 0, lastError = '';

  /** Story/world flags that are saved; names match the save format. */
  function freshFlags() {
    return { fuseInstalled: false, crawlerDead: false, tarantulaDead: false, bossProvoked: false, bossTrapped: false };
  }

  /* ---------------------------------------------------------------- state machine */

  /**
   * Switches the top-level state. Flushing input swallows the key press that caused the
   * switch, so one tap of Esc/Tab/E cannot open and immediately close a screen.
   * @param {string} s menu | playing | paused | journal | note | dead | win
   */
  g.setState = function (s) {
    g.state = s;
    Z.Input.flush();
    Z.Audio.setMuted(s === 'paused');                    // spec: mute in the pause menu
    if (s === 'menu' || s === 'dead' || s === 'win') Z.Audio.setAmbient(false);
    else Z.Audio.setAmbient(!!(g.room && g.room.ambient));
  };

  /**
   * Fades to black, runs cb while the screen is fully black, then fades back in.
   * World updates are frozen while a fade runs.
   * @param {Function} cb work to do unseen (swap room, move player...)
   * @param {number} [half] frames per half; DECISION: default 12 frames (200 ms) each way, slower fades build dread
   */
  g.fadeTo = function (cb, half) {
    g.fade = { phase: 1, t: 0, len: half || 12, a: 0, cb: cb || null };
  };

  /**
   * Instantly loads a room (call only while the screen is black). Unknown ids fall back to the
   * salon so a typo in room data can never crash the game.
   * @param {string} id room id in Z.Rooms.ROOMS
   * @param {{x:number,y:number}|string|null} spawn explicit position, named entrance, or null for the default
   */
  g.enterRoom = function (id, spawn) {
    if (!Z.Rooms.ROOMS[id]) {
      console.warn('ZSYP: unknown room "' + id + '", falling back to salon');
      id = 'salon';
      spawn = null;
    }
    Z.Rooms.enter(g, id, spawn);
    Z.Audio.setAmbient(!!(g.room && g.room.ambient));
  };

  /**
   * Room transition with the standard fade (used by exits, stairs, ladders, hatches).
   * @param {string} id target room id
   * @param {*} spawn see enterRoom
   */
  g.changeRoom = function (id, spawn) {
    if (g.fade.phase !== 0) return;                      // already transitioning: ignore double triggers
    g.fadeTo(function () { g.enterRoom(id, spawn); }, 12);
  };

  /**
   * Puts the player back at the current room's entrance after a fade
   * (fell out of the room: 18 frames = 300 ms; trapdoor fall: pass 30 = 500 ms).
   * @param {number} [half] fade frames per half
   */
  g.respawn = function (half) {
    if (g.fade.phase !== 0) return;
    g.fadeTo(function () {
      var p = g.player;
      p.x = g.entrance.x; p.y = g.entrance.y;
      p.vx = 0; p.vy = 0;
    }, half || 18);
  };

  /** Starts the death sequence: world freezes and fades to black over 1 s, then the "Zginąłeś" screen. */
  g.die = function () {
    if (g.state !== 'playing' || g.dyingT > 0) return;
    g.dyingT = 1;
    Z.Audio.setAmbient(false);
  };

  /** Called by the boss-trap sequence once the cage has slammed. Never skipped: always ends on the win screen. */
  g.win = function () {
    if (g.state !== 'playing' || g.fade.phase !== 0) return;
    Z.Audio.play('win');
    g.fadeTo(function () { g.setState('win'); }, 60);   // DECISION: slow 1 s fade so the cage slam lingers
  };

  /**
   * Opens the note viewer for a note that was just collected (or is re-read from the journal).
   * @param {string} id e.g. 'note_08'
   */
  g.openNote = function (id) {
    g.noteId = id;
    Z.Audio.play('pickup');
    g.setState('note');
  };

  /** Common reset shared by new game and load game. */
  function resetSession() {
    Z.Audio.init();                     // an AudioContext may only start inside a user gesture
    g.flags = freshFlags();
    Z.Inventory.reset(g);
    g.player = Z.Player.create();
    g.dyingT = 0; g.noteId = null; g.prompt = null;
  }

  function beginRun() {
    g.fade = { phase: 2, t: 0, len: 24, a: 1, cb: null };   // open from black
    g.setState('playing');
  }

  /** Starts a fresh game in the salon. */
  g.newGame = function () {
    resetSession();
    g.enterRoom('salon', null);
    beginRun();
  };

  /** Restores the localStorage save; a missing or corrupt save quietly starts a new game instead of crashing. */
  g.loadGame = function () {
    var data = Z.Save.read();
    if (!data) { g.newGame(); return; }
    resetSession();
    try {
      Z.Save.apply(g, data);            // restores flags, inventory, stats, then calls g.enterRoom(...)
    } catch (err) {
      console.warn('ZSYP: save could not be applied, starting a new game', err);
      g.newGame();
      return;
    }
    beginRun();
  };

  /* ---------------------------------------------------------------- simulation */

  /** Advances the fade; the callback runs exactly once, at full black. */
  function stepFade() {
    var f = g.fade;
    if (f.phase === 0) return;
    f.t++;
    if (f.phase === 1) {
      f.a = Math.min(1, f.t / f.len);
      if (f.t >= f.len) {
        f.phase = 2; f.t = 0;
        var cb = f.cb; f.cb = null;
        if (cb) cb();
      }
    } else {
      f.a = Math.max(0, 1 - f.t / f.len);
      if (f.t >= f.len) { f.phase = 0; f.a = 0; }
    }
  }

  function updatePlaying() {
    if (g.dyingT > 0) {                  // death: world is frozen while the screen fades out
      if (++g.dyingT > 60) { g.dyingT = 0; g.setState('dead'); }
      return;
    }
    if (g.fade.phase === 0) {            // world also frozen while the screen is mid-fade
      if (Z.Input.pressed('pause')) { g.setState('paused'); return; }
      if (Z.Input.pressed('inventory')) { g.setState('journal'); return; }
      g.prompt = null;
      Z.Player.update(g);
      Z.Enemies.update(g);
      Z.Items.update(g);
      Z.Rooms.update(g);
      g.time++;
    }
    Z.Render.updateParticles();
  }

  function handleAction(act) {
    if (act === 'new') g.newGame();
    else if (act === 'load') g.loadGame();
    else if (act === 'resume' || act === 'close') g.setState('playing');
    else if (act === 'menu') g.setState('menu');
  }

  /** One fixed simulation step (1/60 s). */
  function update() {
    Z.Input.tick();
    stepFade();
    if (g.state === 'playing') { updatePlaying(); return; }
    var scr = Z.UI.screens[g.state];
    var act = scr && scr.update(g);
    if (act) handleAction(act);
  }

  /* ---------------------------------------------------------------- drawing */

  function overlay(ctx, a) {
    ctx.fillStyle = 'rgba(0,0,0,' + a.toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
  }

  function drawWorld(ctx) {
    var o = Z.Render.shakeOffset();      // {x,y}; the shake timer decays inside updateParticles
    ctx.save();
    ctx.translate(o.x, o.y);
    Z.Rooms.draw(ctx, g);                // background, platforms, props
    Z.Items.draw(ctx, g);
    Z.Enemies.draw(ctx, g);
    Z.Player.draw(ctx, g);
    Z.Render.drawParticles(ctx);
    ctx.restore();
    // Drawn after restore: a shaking world must not reveal gaps at the screen edge of the darkness.
    if (g.room.dark) Z.Render.vignette(ctx, g);
  }

  function draw() {
    var ctx = g.ctx, s = g.state;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
    if (g.room && g.player && s !== 'menu' && s !== 'dead') {
      drawWorld(ctx);
      if (s !== 'win') Z.UI.hud(ctx, g);
    }
    var scr = Z.UI.screens[s];
    if (scr) scr.draw(ctx, g);
    if (g.dyingT > 0 && s === 'playing') overlay(ctx, Math.min(1, g.dyingT / 60));
    if (g.fade.a > 0) overlay(ctx, g.fade.a);
  }

  /* ---------------------------------------------------------------- loop + boot */

  /** requestAnimationFrame callback with a delta-time accumulator: render at display rate, simulate at exactly 60 Hz. */
  function frame(now) {
    requestAnimationFrame(frame);
    acc += Math.min(now - last, 100);    // clamp: after a tab switch we must not replay seconds of simulation
    last = now;
    try {
      while (acc >= STEP) { update(); acc -= STEP; }
      draw();
    } catch (err) {
      // DECISION: one bad frame must never kill the loop; log it once and drop back to the menu (the save survives).
      acc = 0;
      if (String(err) !== lastError) { lastError = String(err); console.error('ZSYP frame error:', err); }
      g.dyingT = 0;
      g.fade = { phase: 0, t: 0, len: 12, a: 0, cb: null };
      g.setState('menu');
    }
  }

  /** Scales the 1280x720 canvas to the largest 16:9 box that fits; the black body letterboxes the rest. */
  function resize() {
    var s = Math.min(window.innerWidth / W, window.innerHeight / H);
    g.canvas.style.width = Math.floor(W * s) + 'px';
    g.canvas.style.height = Math.floor(H * s) + 'px';
  }

  /** Pause when the tab/window loses focus: nobody should die to a zombie while in another window. */
  function autoPause() {
    if (g.state === 'playing' && g.dyingT === 0) g.setState('paused');
  }

  /** Browsers only allow audio after a gesture, so the first key or click creates the AudioContext. */
  function armAudioUnlock() {
    function unlock() {
      Z.Audio.init();
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('mousedown', unlock);
    }
    window.addEventListener('keydown', unlock);
    window.addEventListener('mousedown', unlock);
  }

  function showMissing(list) {
    var ctx = g.ctx;
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#b33';
    ctx.font = '28px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.fillText('Brakuje modułów gry: ' + list.join(', '), W / 2, H / 2);
    console.error('ZSYP: missing modules: ' + list.join(', '));
  }

  function boot() {
    g.canvas = document.getElementById('game');
    g.ctx = g.canvas.getContext('2d');
    var missing = REQUIRED.filter(function (m) { return !Z[m]; });
    if (missing.length) { showMissing(missing); return; }
    Z.Input.init(g.canvas);
    window.addEventListener('resize', resize);
    window.addEventListener('blur', autoPause);
    document.addEventListener('visibilitychange', function () { if (document.hidden) autoPause(); });
    resize();
    armAudioUnlock();
    g.canvas.focus();
    last = performance.now();
    requestAnimationFrame(frame);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window.ZSYP = window.ZSYP || {});