// FILE: js/input.js
/*
 * Keyboard + mouse. Polled once per simulation step via Input.tick(), so game code can ask
 * "is it down?", "how many frames has it been held?" (the bunker valve needs 120) and
 * "was it pressed this frame?" without caring about browser event timing.
 */
(function (Z) {
  'use strict';

  var ACTIONS = ['left', 'right', 'jump', 'crouch', 'attack', 'cycle', 'interact',
                 'flashlight', 'inventory', 'pause', 'confirm', 'up', 'down'];

  /**
   * Physical key (KeyboardEvent.code, layout independent) -> actions.
   * 'up', 'down' and 'confirm' exist only for menu navigation; they add no gameplay controls.
   */
  var KEYS = {
    ArrowLeft: ['left'], KeyA: ['left'],
    ArrowRight: ['right'], KeyD: ['right'],
    Space: ['jump', 'confirm'], KeyW: ['jump', 'up'], ArrowUp: ['jump', 'up'],
    ArrowDown: ['down'], KeyS: ['down'],
    ShiftLeft: ['crouch'], ShiftRight: ['crouch'], KeyC: ['crouch'],
    KeyJ: ['attack'], KeyQ: ['cycle'], KeyE: ['interact', 'confirm'], KeyF: ['flashlight'],
    Tab: ['inventory'], Escape: ['pause'], Enter: ['confirm']
  };

  var codes = {};                                  // physical keys currently held
  var down = {}, tapped = {}, held = {}, eaten = {};
  var mouse = { x: 640, y: 360, left: false };     // x/y in internal 1280x720 coordinates

  ACTIONS.forEach(function (a) { down[a] = tapped[a] = eaten[a] = false; held[a] = 0; });

  /** Rebuilds per-action "down" from the physical keys, so A and ← can be held together without one cancelling the other. */
  function recompute() {
    ACTIONS.forEach(function (a) { down[a] = false; });
    Object.keys(codes).forEach(function (c) {
      if (codes[c]) KEYS[c].forEach(function (a) { down[a] = true; });
    });
    if (mouse.left) down.attack = true;
  }

  function onKey(e, isDown) {
    var list = KEYS[e.code];
    if (!list) return;
    e.preventDefault();                            // no Tab focus-jumps, no Space/arrow page scrolling
    if (isDown && !e.repeat && !codes[e.code]) {
      // A "tap" is remembered even if the key is released before the next simulation step.
      list.forEach(function (a) { tapped[a] = true; });
    }
    codes[e.code] = isDown;
    recompute();
  }

  function toGame(e, canvas) {
    var r = canvas.getBoundingClientRect();
    mouse.x = (e.clientX - r.left) * (canvas.width / r.width);
    mouse.y = (e.clientY - r.top) * (canvas.height / r.height);
  }

  /** Drops every held key; used on window blur so keys cannot get "stuck" while the window is unfocused. */
  function releaseAll() {
    codes = {};
    mouse.left = false;
    recompute();
  }

  /**
   * Attaches all listeners. Call once at boot.
   * @param {HTMLCanvasElement} canvas used to map mouse positions to internal coordinates
   */
  function init(canvas) {
    window.addEventListener('keydown', function (e) { onKey(e, true); });
    window.addEventListener('keyup', function (e) { onKey(e, false); });
    window.addEventListener('blur', releaseAll);
    canvas.addEventListener('mousemove', function (e) { toGame(e, canvas); });
    canvas.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      toGame(e, canvas);
      mouse.left = true;
      tapped.attack = true;
      recompute();
      canvas.focus();
    });
    window.addEventListener('mouseup', function (e) {
      if (e.button === 0) { mouse.left = false; recompute(); }
    });
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  }

  /** Called once at the start of every simulation step: turns raw key state into per-action frame counters. */
  function tick() {
    ACTIONS.forEach(function (a) {
      if (eaten[a]) {                              // consumed by flush(): ignore until the key is released
        if (!down[a]) eaten[a] = false;
        held[a] = 0; tapped[a] = false;
        return;
      }
      held[a] = (down[a] || tapped[a]) ? held[a] + 1 : 0;
      tapped[a] = false;
    });
  }

  Z.Input = {
    init: init,
    tick: tick,
    mouse: mouse,
    /** @param {string} a action name @returns {boolean} true while the action is held */
    down: function (a) { return held[a] > 0; },
    /** @param {string} a action name @returns {number} consecutive simulation frames the action has been held (0 = not held) */
    held: function (a) { return held[a]; },
    /** @param {string} a action name @returns {boolean} true only on the first frame of a press */
    pressed: function (a) { return held[a] === 1; },
    /** Marks every currently held action as consumed until released; call when a key press changes game state. */
    flush: function () {
      ACTIONS.forEach(function (a) {
        if (held[a] > 0 || down[a]) { held[a] = 0; eaten[a] = true; }
        tapped[a] = false;
      });
    }
  };
})(window.ZSYP = window.ZSYP || {});