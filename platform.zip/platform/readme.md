<!-- FILE: README.md -->
# ZSYP (The Chute)

A 2D horror platformer in vanilla HTML5/CSS/JavaScript. After the blast, a lone survivor is trapped in a six-level family house. An invincible experiment-monster sleeps in the bunker under the basement: lure it out, lead it to the kitchen and drop it through the trash chute into the cage waiting below.

**Run it:** open `index.html` in Chrome, Firefox or Safari (works from `file://`). No server, no build step, no network, no external files. All in-game text is Polish; code and comments are English.

## Controls

| Key | Action |
|---|---|
| A / D or ← / → | Move |
| Double-tap a direction, keep holding | Sprint (needs stamina > 20) |
| Space, W or ↑ | Jump (disabled in crouch-only rooms) |
| Shift or C (hold) | Crouch (half speed, no jump, no sprint) |
| J or left mouse button | Attack with the current weapon |
| Q | Cycle weapon (knife ↔ crossbow) |
| E | Interact: pick up, read, save at candles, lever, fuse box, kitchen table. Hold 2 s at the bunker valve |
| F | Flashlight on/off |
| Tab | Inventory + journal (arrows or WASD move, Enter/E/click uses an item, Tab or Esc closes) |
| Esc | Pause |

Menus use W/S or ↑/↓ with Enter, Space or E, or the mouse. Candles save to `localStorage` (key `zsyp_save_v1`) and heal 20 HP. "Wczytaj zapis" works from the main menu, the pause screen and the death screen.

## File map

| File | Purpose |
|---|---|
| `index.html`, `style.css` | Page shell: one 1280×720 canvas, letterboxed |
| `js/input.js` | Keyboard and mouse, polled once per simulation step |
| `js/audio.js` | Web Audio synthesis of every sound |
| `js/render.js` | Overlap test, screen shake, particles, darkness vignette |
| `js/player.js` | Player physics, crouch, stamina, flashlight, weapons, damage |
| `js/enemies.js` | Zombie, crawler, tarantula, the boss; the `ENEMIES` factory table |
| `js/items.js` | Pickups and the `ITEMS` table |
| `js/inventory.js` | Six slots, the 15 Polish journal notes, poison crafting |
| `js/ui.js` | HUD, menu, pause, inventory + journal, note viewer, death, win |
| `js/rooms.js` | Room engine: registry, exits, props, trapdoor, boss-trap cutscene, drawing |
| `js/rooms_data.js` | The 17 rooms as pure data |
| `js/save.js` | Save and load |
| `js/main.js` | Boot, fixed 60 Hz loop, top-level state machine |

Load order matters (see `index.html`): `rooms_data.js` after `rooms.js`, `main.js` last. Search the code for `DECISION:` to find every place where the spec was ambiguous or extended.

## Extending the game

**Add a room.** Call `Z.Rooms.registerRoom(id, data)` from any script loaded after `rooms.js`. The data shape (platforms, spawns, exits, props, items, enemies, hazards) is documented at the top of `js/rooms_data.js`. Link the room by adding an `exits` entry or a `door`/`stairs`/`ladder`/`hatch` prop to an existing room (`to` is the room id, `at` a named spawn in the target). A new prop kind needs one entry each in `USE`, `PROMPT` (optional) and `DRAW` in `rooms.js`.

**Add an enemy.** Set `Z.Enemies.ENEMIES.<type> = { create(x, y, opts), update(g, e), draw(ctx, g, e) }` and list `{ type, x, y }` in a room's `enemies`. `create` must return the shared fields `type, x, y, w, h, vx, vy, hp, dead, deadT, face, t, dots, stun, onGround, hitWall, gravity`, plus an optional `onDeath(g, e)`. Hurt the player with `Z.Player.hurt(g, dmg)`; weapon hits arrive through `Z.Enemies.damage`.

**Add an item.** Set `Z.Items.ITEMS.<id> = { name, color, prompt, pickup(g, it), use(g) }` and list `{ id, x, y }` in a room's `items` (add a `uid` to tell two pickups with the same id apart). `pickup` returns true when the item leaves the world. `use` is optional: it runs from the Tab menu and returns a message. Slot logic lives in `Z.Inventory.add / consume / has / wasUsed`.

## How the sequel plugs in

The front door in `przedpokoj` is a `chained` prop, locked for the whole chapter, and the last note ends with "Zima nuklearna dopiero się zaczyna." Chapter 2 only needs one new script (`<script src="js/sequel.js"></script>` after `rooms_data.js`):

```js
(function (Z) {
  var hall = Z.Rooms.ROOMS.przedpokoj;
  hall.props = hall.props.map(function (p) {            // unchain the front door
    return p.kind !== 'chained' ? p : { kind: 'door', x: p.x, y: 520, w: 70, h: 130,
      label: 'Drzwi wejściowe', to: 'zima_podworko', at: 'default', need: null, reach: 0 };
  });
  Z.Rooms.registerRoom('zima_podworko', {
    name: 'Podwórko', floor: 'Zima', bgColor: '#aab4c0', fg: '#58606a',
    platforms: [{ x: 0, y: 650, w: 1280, h: 70 }, { x: 0, y: 0, w: 1280, h: 40 }],
    spawns: { default: { x: 60, y: 602 } },
    exits: [{ kind: 'edge', side: 'left', y0: 540, y1: 660, to: 'przedpokoj', at: 'default', need: null }]
  });
})(window.ZSYP);
```

Saves already store `bossTrapped`, `notesCollected` and `itemsUsed`, so a sequel can branch on how chapter 1 ended.